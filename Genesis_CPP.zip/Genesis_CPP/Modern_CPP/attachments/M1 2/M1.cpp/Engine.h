#ifndef ENGINE_H
#define ENGINE_H
#include<string>
#include"EngineType.h"

class Engine
{
private: 
    std::string _EngineNumber;
    int _EngineHorsepower;
    ENGINETYPE _EngineType;
    int _EngineTorque;
public:
    Engine()=default;
    Engine(std::string EngineNumber, int EngineHorsepower,ENGINETYPE EngineType,int EngineTorque);

    std::string engineNumber() const { return _EngineNumber; }
    void setEngineNumber(const std::string &EngineNumber) { _EngineNumber = EngineNumber; }

    int engineHorsepower() const { return _EngineHorsepower; }
    void setEngineHorsepower(int EngineHorsepower) { _EngineHorsepower = EngineHorsepower; }

    int engineTorque() const { return _EngineTorque; }
    void setEngineTorque(int EngineTorque) { _EngineTorque = EngineTorque; }

    ENGINETYPE engineType() const { return _EngineType; }
    

  
   

};

#endif // ENGINE_H
