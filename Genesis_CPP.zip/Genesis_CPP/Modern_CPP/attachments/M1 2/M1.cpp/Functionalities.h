#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H
#include<string>
#include"Car.h"
#include<vector>
#include<memory>
using Pointer = std::shared_ptr<Car>;
using Container = std::vector<Pointer>;
using v1 = std::vector<Engine>;

int Find(Container& data,std::string CarId);
Container Find1(Container& data);
std::vector<Engine>  Find2(Container& data,CARTYPE C);
void FindAvg(Container& data,ENGINETYPE E,int carp);
void FindLow(Container& data);

int FindCombined(Pointer p1,Pointer p2);
void CreateObjects(Container& data,std::vector<Engine>& v);

#endif // FUNCTIONALITIES_H
