#include<iostream>
#include"Car.h"
#include"Engine.h"
Car::Car(std::string CarId, std::string CarBrand, CARTYPE CarType, float CarPrice, Engine& CarEngine):_CarId(CarId),_CarBrand(CarBrand),_CarType(CarType),_CarPrice(CarPrice),_CarEngine(CarEngine)
{

}
