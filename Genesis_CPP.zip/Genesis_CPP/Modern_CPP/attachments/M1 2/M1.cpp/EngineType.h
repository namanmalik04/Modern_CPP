#ifndef ENGINETYPE_H
#define ENGINETYPE_H

enum class ENGINETYPE
{
    ICT,
    HYBRID

};

#endif // ENGINETYPE_H
