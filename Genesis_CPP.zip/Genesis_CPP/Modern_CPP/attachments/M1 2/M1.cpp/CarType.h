#ifndef CARTYPE_H
#define CARTYPE_H

enum class CARTYPE 
{
    SEDAN,
    SPORTS,
    SUV,
    HATCHBACK,
};

#endif // CARTYPE_H
