#ifndef CAR_H
#define CAR_H
#include<string>
#include"CarType.h"
#include"Engine.h"
class Car 
{
private:
    std::string _CarId;
    std::string _CarBrand;
    CARTYPE _CarType;
    float _CarPrice;
    Engine& _CarEngine;
public:
    Car()=default;
    Car(std::string CarId, std::string CarBrand, CARTYPE CarType, float CarPrice, Engine& CarEngine);



    std::string carId() const { return _CarId; }
    void setCarId(const std::string &CarId) { _CarId = CarId; }
    std::string carBrand() const { return _CarBrand; }
    void setCarBrand(const std::string &CarBrand) { _CarBrand = CarBrand; }
    float carPrice() const { return _CarPrice; }
    void setCarPrice(float CarPrice) { _CarPrice = CarPrice; }

    CARTYPE carType() const { return _CarType; }

    Engine& carEngine() const { return _CarEngine; }
    

};

#endif // CAR_H
