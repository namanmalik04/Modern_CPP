#include<iostream>
#include<vector>
#include"Functionalities.h"
#include"Car.h"
int main()
{
    Container data;
    v1 e;
    CreateObjects(data,e);
    Find(data,"2");
    Find1( data);
    Find2( data,CARTYPE::SEDAN);
    FindAvg( data,ENGINETYPE::HYBRID,890000);
    FindLow( data);

//  FindCombined();



}