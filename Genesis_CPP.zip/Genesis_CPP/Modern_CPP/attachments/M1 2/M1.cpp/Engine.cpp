#include "Engine.h"

Engine::Engine(std::string EngineNumber, int EngineHorsepower, ENGINETYPE EngineType, int EngineTorque):_EngineNumber(EngineNumber), _EngineHorsepower(EngineHorsepower), _EngineType(EngineType), _EngineTorque(EngineTorque)
{
    
}