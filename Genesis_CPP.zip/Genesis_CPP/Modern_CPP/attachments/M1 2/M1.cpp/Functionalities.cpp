#include "Functionalities.h"
#include<memory>
#include<iostream>
#include"Engine.h"
int FindCombined(Pointer p1, Pointer p2)
{
    int s=0;
    s=s+p1->carPrice()+p2->carPrice();
    return s;
}
void CreateObjects(Container &data, v1 &v)
{
    Engine E("1",500,ENGINETYPE::ICT,234);
    v.push_back(E);
    data.push_back(std::make_shared<Car>("1","BMW",CARTYPE::HATCHBACK,890000, v[0]));

    Engine E1("2",600,ENGINETYPE::HYBRID,235);
    v.push_back(E1);
    data.push_back(std::make_shared<Car>("2","Audi",CARTYPE::SPORTS,890000, v[1]));

    Engine E2("2",700,ENGINETYPE::ICT,236);
    v.push_back(E2);
    data.push_back(std::make_shared<Car>("3","Benz",CARTYPE::SEDAN,890000, v[2]));

}
int Find(Container &data, std::string CarId)
{
    for(auto i : data)
    {
        if(i->carId()==CarId)
            return i->carEngine().engineHorsepower();
        else
            std::cout<<"Id not found";
    }
    return 0;
}

Container Find1(Container &data)
{
    Container c;
    for(auto i: data)
    {
        if(i->carEngine().engineTorque()> 80)
        {
            c.push_back(i);
        }
    }
    return c;
}

std::vector<Engine> Find2(Container &data, CARTYPE C)
{
    std::vector<Engine> e;
    for(auto i: data)
    {
        if(i->carType()==C)
        {
            e.push_back(i->carEngine());
        }
    }
    return e;
}

void FindAvg(Container &data, ENGINETYPE E, int carp)
{
    int s=0;
    for(auto i:data)
    {
        if(i->carEngine().engineType()==E && i->carPrice()>1000000)
            s=s+i->carEngine().engineHorsepower();
    }
    std::cout<<"The average is "<<(float)s/3;
}

void FindLow(Container &data)
{
    int m=data[0]->carPrice();
    for(auto i:data)
    {
        if(i->carPrice()<m)
            m=i->carPrice();
    }
    std::cout<<"The minimum price is "<<m<<std::endl;
}
