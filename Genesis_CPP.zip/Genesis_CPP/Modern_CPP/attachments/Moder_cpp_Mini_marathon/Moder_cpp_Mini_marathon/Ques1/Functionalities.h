#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include "Sensor.h"
#include <list>
#include <functional>
#include <memory>

using Pointer = std :: shared_ptr<Sensor>;
using Container = std :: list<Pointer>;

void CreateObject(Container &data);

bool CheckReading(Container &data);
bool CheckException(int &_reading);

float AverageReading(Container &data, SensorType sensorType);

std :: list<Sensor>ReadingType(Container &data);





#endif // FUNCTIONALITIES_H
