#ifndef NEGATIVEEXCEPTION_H
#define NEGATIVEEXCEPTION_H

#include <stdexcept>
#include <cstring>


class NegativeException
{
private:

    char* _msg;
    
public:
    NegativeException()= delete;
    explicit NegativeException(const char* msg) {
        _msg = new char[strlen(msg) + 1];
        strcpy(_msg,msg);
    }
    NegativeException(const NegativeException&) = default;
    NegativeException(NegativeException&&) = default;
    NegativeException& operator=(const NegativeException&) = delete;
    NegativeException& operator=(NegativeException&&) = default;
    ~NegativeException() = default;

    virtual const char * what() {return _msg;}
};



#endif // NEGATIVEEXCEPTION_H
