#include "Functionalities.h"
#include "SensorType.h"
#include "NegativeException.h"
#include "LimitReadingExceed.h"
#include "DivisibeException.h"

bool CheckException(int &_reading){
    if(_reading < 0)
        throw NegativeException("Neagive value not allowed!\n");
    
    if(_reading % 10 == 0)
        throw DivisibeException("Reading could not divisible by 10!\n");

    if(_reading > 20)
        throw LimitReadingExceed("Reading greater than 25 not allowed!\n");

    return true;
}


void CreateObject(Container &data)
{
    int reading;

    std :: cout << "Enter Reading for 1st Sensor : ";
    std :: cin >> reading;
    
    if(CheckException(reading)){
        data.push_back(std :: make_shared<Sensor>(
            011, "abc", SensorType :: TEMPERATURE, reading
        ));
    }


    std :: cout << "Enter Reading for 2nd Sensor : ";
    std :: cin >> reading;

    if(CheckException(reading)){
        data.push_back(std :: make_shared<Sensor>(
            012, "mno", SensorType :: TYRE_PRESSURE, reading
        ));
    }



    std :: cout << "Enter Reading for 3rd Sensor : ";
    std :: cin >> reading;

    if(CheckException(reading)){
        data.push_back(std :: make_shared<Sensor>(
            reading, "xyz", SensorType :: CABIN_PRESSURE, reading
        ));
    }
}

bool CheckReading(Container &data)
{
    for(std :: shared_ptr <Sensor> i : data){
        if(i->reading() > 25)
            return true;
    }
    return false;
}

float AverageReading(Container &data, SensorType sensorType)
{
    float average = 0.0f;
    int counter = 0;

    
    for(std :: shared_ptr <Sensor> i : data){

        if(i->sensorType() == sensorType){
            average += (float)(i->reading());
            counter++;
        }
    }

    return average / (float) counter;
}


std::list<Sensor> ReadingType(Container &data)
{

    std :: list<Sensor>sensorInstance;

    for(std :: shared_ptr <Sensor> i : data){
        if(i -> reading() > 15 && i->sensorType() == SensorType :: TYRE_PRESSURE){
            sensorInstance.push_back(*i);
        }
    }

    return sensorInstance;
}
