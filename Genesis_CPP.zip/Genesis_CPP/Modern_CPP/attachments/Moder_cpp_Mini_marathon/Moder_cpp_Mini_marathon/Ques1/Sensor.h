#ifndef SENSOR_H
#define SENSOR_H

#include <iostream>
#include "SensorType.h"

class Sensor
{
private:

    const int _id;
    std :: string _name;
    SensorType _sensorType;
    int _reading;
    
public:

    Sensor(const int id, std::string name, SensorType sensorType, int reading);
    Sensor() = delete;
    Sensor(const Sensor &) = default;
    Sensor(Sensor &&) = delete;
    Sensor operator=(Sensor &) = delete;
    Sensor operator=(Sensor &&) = delete;
    ~Sensor() = default;

    int id() const { return _id; }

    std :: string name() const { return _name; }
    void setName(const std :: string &name) { _name = name; }

    SensorType sensorType() const { return _sensorType; }
    void setSensorType(const SensorType &sensorType) { _sensorType = sensorType; }

    int reading() const { return _reading; }
    void setReading(int reading) { _reading = reading; }

    friend std::ostream &operator<<(std::ostream &os, const Sensor &rhs);

    
};




#endif // SENSOR_H
