#include <iostream>
#include "Functionalities.h"
#include "LimitReadingExceed.h"
#include "DivisibeException.h"
#include "NegativeException.h"

int main(){
    Container data;

    try{
        CreateObject(data);
    }
    catch(LimitReadingExceed &e){
        std :: cout << e.what() << "\n";
    }
    catch(DivisibeException &e){
        std :: cout << e.what() << "\n";
    }
    catch(NegativeException &e){
        std :: cout << e.what() << "\n";
    }

    if(CheckReading(data)){
        std :: cout << "At least one instance have reading above 25 " << "\n\n";
    }
    else{
        std :: cout << "No instance have reading above 25 " << "\n";
    }

    std :: cout << "Average reading : " << (float)AverageReading(data,SensorType :: TEMPERATURE) << "\n\n";

    std :: list<Sensor>sensorInstance = ReadingType(data);

    std :: cout << "All instance of Sensor with Reading avove 15 and TYRE_PRESSURE are : " << "\n";
    for(Sensor i : sensorInstance){
        std :: cout << i;
    }
}