#ifndef DIVISIBEEXCEPTION_H
#define DIVISIBEEXCEPTION_H

#include <stdexcept>
#include <cstring>


class DivisibeException
{
private:

    char* _msg;
    
public:
    DivisibeException()= delete;
    explicit DivisibeException(const char* msg) {
        _msg = new char[strlen(msg) + 1];
        strcpy(_msg,msg);
    }
    DivisibeException(const DivisibeException&) = default;
    DivisibeException(DivisibeException&&) = default;
    DivisibeException& operator=(const DivisibeException&) = delete;
    DivisibeException& operator=(DivisibeException&&) = default;
    ~DivisibeException() = default;

    virtual const char * what() {return _msg;}
};



#endif // DIVISIBEEXCEPTION_H
