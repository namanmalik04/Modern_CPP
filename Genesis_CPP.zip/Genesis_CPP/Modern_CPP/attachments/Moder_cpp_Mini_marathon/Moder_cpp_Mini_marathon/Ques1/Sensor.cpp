#include "Sensor.h"

Sensor :: Sensor(const int id, std::string name, SensorType sensorType, int reading) :
_id(id), _name(name), _sensorType(sensorType), _reading(reading) {}

std::ostream &operator<<(std::ostream &os, const Sensor &rhs) {

    os << "_id: " << rhs._id << "\n"
       << " _name: " << rhs._name << "\n"
       //<< " _sensorType: " << static_cast<int>(rhs._sensorType) << "\n"
       << " _reading: " << rhs._reading << "\n"
        << "_sensorType: ";
        
    switch (static_cast<int>(rhs._sensorType))
    {
    case 0:
        std :: cout << "TYRE_PRESSURE" << "\n";
        break;
    
    case 1:
        std :: cout << "TEMPERATURE" << "\n";
        break;

    case 3:
        std :: cout << "CABIN_PRESSURE" << "\n";
        break;
    
    default:
        break;
    }
    return os;
}

