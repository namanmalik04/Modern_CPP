#ifndef LIMITREADINGEXCEED_H
#define LIMITREADINGEXCEED_H

#include <stdexcept>
#include <cstring>


class LimitReadingExceed
{
private:

    char* _msg;
    
public:
    LimitReadingExceed()= delete;
    explicit LimitReadingExceed(const char* msg) {
        _msg = new char[strlen(msg) + 1];
        strcpy(_msg,msg);
    }
    LimitReadingExceed(const LimitReadingExceed&) = default;
    LimitReadingExceed(LimitReadingExceed&&) = default;
    LimitReadingExceed& operator=(const LimitReadingExceed&) = delete;
    LimitReadingExceed& operator=(LimitReadingExceed&&) = default;
    ~LimitReadingExceed() = default;

    virtual const char * what() {return _msg;}
};


#endif // LIMITREADINGEXCEED_H
