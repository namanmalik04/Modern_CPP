#ifndef SENSORTYPE_H
#define SENSORTYPE_H

enum class SensorType{
    TYRE_PRESSURE,
    TEMPERATURE,
    CABIN_PRESSURE
};

#endif // SENSORTYPE_H
