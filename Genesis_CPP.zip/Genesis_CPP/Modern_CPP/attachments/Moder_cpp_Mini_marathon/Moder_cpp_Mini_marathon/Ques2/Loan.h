#ifndef LOAN_H
#define LOAN_H

#include "LoanIntentType.h"
#include <iostream>

class Loan
{
private:
    const int _personId;
    int _personAge;
    int _personIncome;
    LoanIntent _loanIntent;
    int _loanAmount;
    float int_rate;
    int _status;
public:
    Loan(const int personId, int personAge, int personIncome, LoanIntent loanIntent, int loanAmount, float rate, int status);
   
    Loan() = delete;
    Loan(const Loan &) = default;
    Loan(Loan &&) = delete;
    Loan operator=(Loan &) = delete;
    Loan operator=(Loan &&) = delete;
    ~Loan() = default;

    int personId() const { return _personId; }

    int personAge() const { return _personAge; }
    void setPersonAge(int &personAge) { _personAge = personAge; }

    int personIncome() const { return _personIncome; }
    void setPersonIncome(int personIncome) { _personIncome = personIncome; }

    LoanIntent loanIntent() const { return _loanIntent; }
    void setLoanIntent(const LoanIntent &loanIntent) { _loanIntent = loanIntent; }

    int loanAmount() const { return _loanAmount; }
    void setLoanAmount(int loanAmount) { _loanAmount = loanAmount; }

    float rate() const { return int_rate; }
    void setRate(float rate) { int_rate = rate; }

    int status() const { return _status; }
    void setStatus(int status) { _status = status; }

    friend std::ostream &operator<<(std::ostream &os, const Loan &rhs);


    

};




#endif // LOAN_H
