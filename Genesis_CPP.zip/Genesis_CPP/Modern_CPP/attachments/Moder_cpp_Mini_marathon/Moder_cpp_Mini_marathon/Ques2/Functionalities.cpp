#include "Functionalities.h"
#include <algorithm>
#include "DataEmptyException.h"

void CreateObject(Container &data){


    data.push_back(
        std :: make_shared<Loan>(
            1,22,590000,LoanIntent::PERSONAL,35000,16.02,1
        )
    );


    data.push_back(
        std :: make_shared<Loan>(
            2,25,9600,LoanIntent::MEDICAL,5500,12.87,1
        )
    );


    data.push_back(
        std :: make_shared<Loan>(
            3,23,65500,LoanIntent::MEDICAL,35000,15.23,0
        )
    );

    data.push_back(
        std :: make_shared<Loan>(
            4,24,54400,LoanIntent::MEDICAL,35000,14.27,1
        )
    );

    data.push_back(
        std :: make_shared<Loan>(
            5,21,9900,LoanIntent::VENTURE,2500,7.14,0
        )
    );

   

    data.push_back(
        std :: make_shared<Loan>(
            6,26,77100,LoanIntent::EDUCATION,35000,12.42,1
        )
    );

    data.push_back(
        std :: make_shared<Loan>(
            7,24,78956,LoanIntent::MEDICAL,35000,11.11,1
        )
    );

     data.push_back(
        std :: make_shared<Loan>(
            8,22,83000,LoanIntent::PERSONAL,35000,8.9,1
        )
    );

    data.push_back(
        std :: make_shared<Loan>(
            9,21,10000,LoanIntent::VENTURE,1600,14.74,1
        )
    );

    

    data.push_back(
        std :: make_shared<Loan>(
            10,22,85000,LoanIntent::VENTURE,35000,10.37,1
        )
    );
}


int AverageLoanAmount(Container &data, LoanIntent loanIntent){
    float avg = 0.0;
    int count = 0;

    for(auto i : data){
        if(i->loanIntent() == LoanIntent::MEDICAL){
            avg += i->loanAmount();
            count += 1;
        }
    }

    return avg / (float)count;
}

std :: array<int,SIZE>ValueCount(Container &data){

    
    int size = data.size();

    if(size == 0) throw DataEmptyException("Data Not found!");

    std::array<int,SIZE>count;

    for(int i = 0; i < 4; ++i){
        count[i] = 0;
    }
    for(std :: shared_ptr<Loan> i : data){
        if(i->loanIntent() == LoanIntent::EDUCATION){
            count[0]++;
        }
        else if(i->loanIntent() == LoanIntent::PERSONAL){
            count[1]++;
        }
        else if(i->loanIntent() == LoanIntent::MEDICAL){
            count[2]++;
        }
        else{
            count[3]++;
        }
        
    }
    return count;
}

void HighestInterestRateForAcceptedLoans(Container &data){

   
    int size = data.size();

    if(size == 0) throw DataEmptyException("Data Not found!");
    int high_rate = INT_MAX;
    for(auto i : data){
        if(high_rate < i->rate()){
            high_rate = i->rate();
        }
    }

    std :: cout << "Highest rate = " << high_rate << "\n";
}

void MinMaxAge(Container &data){


    int size = data.size();

    if(size == 0) throw DataEmptyException("Data Not found!");

    int _max = INT_MIN;
    int _min = INT_MAX;

    for(auto i : data){
        if(i->personAge() < _max){
            _max = i->personAge();
        }
        if(i->personAge() > _min){
            _min = i->personAge();
        }
    }

    std :: cout << "Highest Age = " << _max << "\n";
    std :: cout << "Lowest Age = " << _min << "\n";
}

Container CheckAmountStatus(Container &data){


    int size = data.size();

    if(size == 0) throw DataEmptyException("Data Not found!");

    Container val;

    if(data.size() == 0) throw DataEmptyException("Data Not found");

    for(auto i : data){
        if((i->loanAmount() >= 20000 && i->loanAmount() <= 40000) && (i->status() == 1) && (i->personAge() > 23)){
            val.push_back(i);
        }
    }

    
    return val;
    
}



int MaxLoanIntRate(Container &data, LoanIntent loanIntent){
    int high_rate = INT_MIN;
    for(auto i : data){
        if(high_rate > i->rate() && i->loanIntent() == loanIntent){
            high_rate = i->rate();
        }
    }

    return high_rate;
}

