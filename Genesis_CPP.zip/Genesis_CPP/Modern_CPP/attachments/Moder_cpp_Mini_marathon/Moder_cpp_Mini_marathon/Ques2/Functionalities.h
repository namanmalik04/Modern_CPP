#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include "Loan.h"
#include <memory>
#include <vector>
#include "LoanIntentType.h"
#include <array>

#define INT_MIN 1e9+7;
#define INT_MAX -10000000;
#define SIZE 4


using Pointer = std :: shared_ptr<Loan>;
using Container = std :: vector<Pointer>;

void CreateObject(Container &data);

int AverageLoanAmount(Container &data, LoanIntent loanIntent);

std :: array<int,SIZE>ValueCount(Container &data);

void HighestInterestRateForAcceptedLoans(Container &data);

void MinMaxAge(Container &data);

Container CheckAmountStatus(Container &data);

int MaxLoanIntRate(Container &data, LoanIntent loanIntent);



#endif // FUNCTIONALITIES_H
