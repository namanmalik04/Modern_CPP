#include "Functionalities.h"
#include "DataEmptyException.h"

int main(){
    Container data;
    CreateObject(data);

    try{
    std :: cout << "Average Loan : " << AverageLoanAmount(data,LoanIntent :: MEDICAL) << "\n";
    }
    catch(DataEmptyException &e){
        std::cout << e.what() << "\n";
    }

    try{
        std::array<int,SIZE>arr = ValueCount(data);
        std :: cout << "Count of intent type : ";
        for(int i : arr){
            std :: cout << i << " ";
    }
    }
     catch(DataEmptyException &e){
        std::cout << e.what() << "\n";
    }

    

   std:: cout << "\n";

    try{
    HighestInterestRateForAcceptedLoans(data);
    }
     catch(DataEmptyException &e){
        std::cout << e.what() << "\n";
    }

    try{
    MinMaxAge(data);
    }
     catch(DataEmptyException &e){
        std::cout << e.what() << "\n";
    }

    try{
    Container c = CheckAmountStatus(data);

    std::cout << "Conatiner with given amount and status : " << "\n";

    for(auto i : c){
        std::cout << *i << "\n";
    }
    }
    catch(DataEmptyException &e){
        std::cout << e.what() << "\n";
    }


    

    try{
    std :: cout << "Highesht Loan int rate : " << MaxLoanIntRate(data,LoanIntent::EDUCATION);
    }
    catch(DataEmptyException &e){
        std::cout << e.what() << "\n";
    }
}