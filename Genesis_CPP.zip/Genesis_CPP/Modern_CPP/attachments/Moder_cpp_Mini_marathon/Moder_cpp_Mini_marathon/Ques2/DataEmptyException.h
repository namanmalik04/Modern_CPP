#ifndef DATAEMPTYEXCEPTION_H
#define DATAEMPTYEXCEPTION_H




#include <stdexcept>
#include <cstring>


class DataEmptyException
{
private:

    char* _msg;
    
public:
    DataEmptyException()= delete;
    explicit DataEmptyException(const char* msg) {
        _msg = new char[strlen(msg) + 1];
        strcpy(_msg,msg);
    }
    DataEmptyException(const DataEmptyException&) = default;
    DataEmptyException(DataEmptyException&&) = default;
    DataEmptyException& operator=(const DataEmptyException&) = delete;
    DataEmptyException& operator=(DataEmptyException&&) = default;
    ~DataEmptyException() = default;

    virtual const char * what() {return _msg;}
};




#endif // DATAEMPTYEXCEPTION_H
