#ifndef LOANINTENTTYPE_H
#define LOANINTENTTYPE_H

enum class LoanIntent{
    PERSONAL,
    MEDICAL,
    EDUCATION,
    VENTURE
};

#endif // LOANINTENTTYPE_H
