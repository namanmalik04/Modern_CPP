#ifndef PERMIT_H
#define PERMIT_H

#include "PermitType.h"
#include <iostream>

class Permit
{
private:
    const std::string _serialNumber;
    PermitType _permitType;
    int _permitDurationLeft;
    

public:

    Permit(const std::string serialNumber,PermitType permitType, int permitDurationLeft);
    Permit() = delete;
    Permit(const Permit &) = default;
    Permit(Permit &&) = delete;
    Permit operator=(Permit &) = delete;
    Permit operator=(Permit &&) = delete;
    ~Permit() = default;

    std::string serialNumber() const { return _serialNumber; }

    PermitType permitType() const { return _permitType; }
    void setPermitType(const PermitType &permitType) { _permitType = permitType; }

    int permitDurationLeft() const { return _permitDurationLeft; }
    void setPermitDurationLeft(int permitDurationLeft) { _permitDurationLeft = permitDurationLeft; }

    friend std::ostream &operator<<(std::ostream &os, const Permit &rhs);

    
};



#endif // PERMIT_H
