   #include "Permit.h"
    Permit::Permit(const std::string serialNumber,PermitType permitType, int permitDurationLeft) : 
    _serialNumber(serialNumber), _permitType(permitType), _permitDurationLeft(permitDurationLeft){}
    std::ostream &operator<<(std::ostream &os, const Permit &rhs) {
        os << "_serialNumber: " << rhs._serialNumber
           << " _permitType: " << static_cast<int>(rhs._permitType)
           << " _permitDurationLeft: " << rhs._permitDurationLeft;
        return os;
    }
