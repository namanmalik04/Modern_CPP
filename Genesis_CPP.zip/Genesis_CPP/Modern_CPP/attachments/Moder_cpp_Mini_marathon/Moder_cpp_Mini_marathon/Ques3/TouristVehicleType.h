#ifndef TOURISTVEHICLETYPE_H
#define TOURISTVEHICLETYPE_H

enum class TouristVehicleType{
    CAR,
    BUS,
    BIKE
};

#endif // TOURISTVEHICLETYPE_H
