#include "Functionalities.h"


int main(){
    Container data;

    CreateObject(data);

    try{
        std::list<TouristVehicle> val = SeatCountPermit(data);
        for(auto i : val){
            std::cout << i << "\n";
        }

    }
    catch(DataEmptyException &e){
        std::cout << e.what() << "\n";
    }

    try{
        std::cout << "Average of Given Tourist vehicle type : " << average(data,TouristVehicleType::BIKE) << "\n";
    }
    catch(DataEmptyException &e){
        std::cout << e.what() << "\n";
    }

   try{
        std::cout << "permit instance serial number : " << SerialNumber(data) << "\n";
    }
    catch(DataEmptyException &e){
        std::cout << e.what() << "\n";
    }

    
    return 0;
}