#include "Functionalities.h"

void CreateObject(Container &data){
    data.push_back(std::make_shared<TouristVehicle>(
        "ty56", TouristVehicleType ::BIKE,56, 89.0,
        std::make_shared<Permit>(
            "fhy78", PermitType::LEASE,67
        )
    ));

    data.push_back(std::make_shared<TouristVehicle>(
        "yu67", TouristVehicleType ::BUS,78, 90.0,
        std::make_shared<Permit>(
            "yu70", PermitType::OWNED,43
        )
    ));


    data.push_back(std::make_shared<TouristVehicle>(
        "io890", TouristVehicleType ::CAR,32, 100.0,
        std::make_shared<Permit>(
            "hy75", PermitType::OWNED,50
        )
    ));

}

std::list<TouristVehicle> SeatCountPermit(Container &data){

    if(data.size() == 0) throw DataEmptyException("data not found !");


    int cnt = 0;

    std::list<TouristVehicle>vehicle;
    std::cout << "Instance whose seat count is greater than 4 : " << "\n";
    for(auto i : data){

        if(i->seatCount() >= 4 && i->permit()->permitType() == PermitType::LEASE){
            cnt++;
            vehicle.push_back(*i);
        }
    }
    return vehicle;
}


int average(Container &data, TouristVehicleType touristvehicleype){
    if(data.size() == 0) throw DataEmptyException("data not found !");

    float avg = 0.0;
    int count = 0;

    for(auto i : data){
        if(i->type() == touristvehicleype){
            avg += i->perHourBookingCharge();
            count++;
        }
    }

    return avg / float(count);
}
std::string SerialNumber(Container &data){

    if(data.size() == 0){
        throw DataEmptyException("data not found !");
    }
    int _max = -10000000;
    
std::string serial = "";

    for(auto i : data){
        if(i->perHourBookingCharge() > _max){
            _max = i->perHourBookingCharge();
            serial = i->permit()->serialNumber();
        }
    }
    
    
    return serial;
}