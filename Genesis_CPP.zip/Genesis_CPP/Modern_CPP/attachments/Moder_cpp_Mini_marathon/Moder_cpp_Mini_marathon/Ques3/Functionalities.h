#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include "TouristVehicle.h"
#include "TouristVehicleType.h"
#include "PermitType.h"
#include "DataEmptyException.h"
#include <list>

using Pointer = std :: shared_ptr<TouristVehicle>;
using Container = std :: list<Pointer>;

void CreateObject(Container &data);
std::list<TouristVehicle> SeatCountPermit(Container &data);
int average(Container &data,TouristVehicleType touristvehicletype);


std::string SerialNumber(Container &data);

#endif // FUNCTIONALITIES_H
