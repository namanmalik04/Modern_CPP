#ifndef TRAIN_H
#define TRAIN_H

#include <iostream>
#include <vector>
#include "TrainTicket.h"
#include <memory>

using TicketContainer = std::vector<std::shared_ptr<TrainTicket>>;


class Train
{
private:

    std::string _trainNumber {""};
    std::string _trainStartingStation {""};
    std::string _trainDestinationStation {""};
    int _trainDepartureHour;
    int _trainDepartureMinute;
    TicketContainer _trainBookedTickets;

    
public:
    
public:

    Train(std::string trainNumber, std::string trainStartingStation, std::string trainDestinationStation, int trainDepartureHour, int trainDepartureMinute, TicketContainer trainBookedTickets);
    
    Train() = delete;
    Train(const Train&) = default;
    Train(const Train&&) = delete;
    Train  const operator=(const Train &) = delete;
    Train  const operator=(const Train &&) = delete;
    ~Train() = default;

    std::string trainNumber() const { return _trainNumber; }
    void setTrainNumber(const std::string &trainNumber) { _trainNumber = trainNumber; }

    std::string trainDestinationStation() const { return _trainDestinationStation; }
    void setTrainDestinationStation(const std::string &trainDestinationStation) { _trainDestinationStation = trainDestinationStation; }

    int trainDepartureHour() const { return _trainDepartureHour; }
    void setTrainDepartureHour(const int &trainDepartureHour) { _trainDepartureHour = trainDepartureHour; }

    std::string trainStartingStation() const { return _trainStartingStation; }
    void setTrainStartingStation(const std::string &trainStartingStation) { _trainStartingStation = trainStartingStation; }

    int trainDepartureMinute() const { return _trainDepartureMinute; }
    void setTrainDepartureMinute(const int &trainDepartureMinute) { _trainDepartureMinute = trainDepartureMinute; }
    
    TicketContainer trainBookedTickets() const { return _trainBookedTickets; }

    friend std::ostream &operator<<(std::ostream &os, const Train &rhs);

    
};



#endif // TRAIN_H
