#ifndef TICKETCLASS_H
#define TICKETCLASS_H

enum class TicketClass{

    FIRST,
    SECOND,
    SLEEPER
    
};

#endif // TICKETCLASS_H
