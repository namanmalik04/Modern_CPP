#ifndef EXCEPTION_H
#define EXCEPTION_H

#include <stdexcept>
#include <cstring>

class Exception
{
private:
    char *_msg;
public:

    Exception(const char *msg){
        _msg = new char[strlen(msg) + 1];
        strcpy(_msg,msg);
    }
    Exception() = delete;
    Exception(const Exception&) = delete;
    Exception(const Exception&&) = delete;
    Exception const operator=(const Exception &) = delete;
    Exception const operator=(const Exception &&) = delete;
    ~Exception() = delete;

    virtual char * what(){
        return _msg;
    }
};




#endif // EXCEPTION_H
