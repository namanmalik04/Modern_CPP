#include "Functionalities.h"

int main(){

    TrainContainer conatiner;

    try{
        CreateObject(conatiner);
    }
    catch(Exception &e){
        std::cout << e.what() << "\n";
    }

    try{
        std::vector<Train> ans = FindDepartureTime(conatiner,12);
        std::cout << "All train wiith departure time within 3 hour : \n\n";

        for(auto &i : ans){
            std::cout << i << " ";
        }

        std::cout << "\n\n";
    }
    catch(Exception &e){
        std::cout << e.what() << "\n";
    }

    if(std::optional<int>val = TotalTicketPrice(conatiner,"123") ; val.has_value()){
        std::cout << "total Price of Tickets : " <<val.value() << "\n\n";
    }
    else{

        std::cout << "Train Not found ! \n\n";

    }

    if(std::optional<Train>val = FindTrainStartingStation(conatiner,"578") ; val.has_value()){
        std::cout << "Train with total ticket price at least 2000 and dept. hour is 15 or 16: " <<val.value() << "\n\n";
    }
    else{

        std::cout << "Train Not found ! \n\n";

    }

    return 0;
}