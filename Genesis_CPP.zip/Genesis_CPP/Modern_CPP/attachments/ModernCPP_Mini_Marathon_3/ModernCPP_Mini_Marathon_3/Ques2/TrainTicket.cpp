#include "TrainTicket.h"

TrainTicket :: TrainTicket(float ticketprice, TicketType ticketType, TicketClass ticketClass) :
_ticketprice(ticketprice) , _ticketType(ticketType), _ticketClass(ticketClass) {}

std::ostream &operator<<(std::ostream &os, const TrainTicket &rhs) {
    os << "_ticketprice: " << rhs._ticketprice << "\n"
       << " _ticketType: " << static_cast<int>(rhs._ticketType) << "\n"
       << " _ticketClass: " << static_cast<int>(rhs._ticketClass) << "\n";
    return os;
}
