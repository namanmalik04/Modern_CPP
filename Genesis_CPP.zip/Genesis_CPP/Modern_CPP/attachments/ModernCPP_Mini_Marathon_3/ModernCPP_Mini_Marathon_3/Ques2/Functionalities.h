#ifndef FUNCTIONALIIES_H
#define FUNCTIONALIIES_H

#include "Train.h"
#include "Exception.h"
#include <optional>


using TrainContainer = std::vector<std::shared_ptr<Train>>;

void CreateObject(TrainContainer &container);

std::vector<Train> FindDepartureTime(TrainContainer &container, int time);

std::optional<int> TotalTicketPrice(TrainContainer &container, std::string number);

std::optional<Train> FindTrainStartingStation(TrainContainer &container, std::string number);

#endif // FUNCTIONALIIES_H
