#include "Train.h"

Train :: Train(std::string trainNumber, std::string trainStartingStation, std::string trainDestinationStation, int trainDepartureHour, int trainDepartureMinute, TicketContainer trainBookedTickets) :
_trainNumber(trainNumber), _trainStartingStation(trainStartingStation), _trainDestinationStation(trainDestinationStation), _trainDepartureHour(trainDepartureHour), _trainDepartureMinute(trainDepartureMinute)
{
    for(auto i : trainBookedTickets)
        _trainBookedTickets.push_back(i);
}

std::ostream &operator<<(std::ostream &os, const Train &rhs) {
    os << "_trainNumber: " << rhs._trainNumber
       << " _trainStartingStation: " << rhs._trainStartingStation << "\n"
       << " _trainDestinationStation: " << rhs._trainDestinationStation << "\n"
       << " _trainDepartureHour: " << rhs._trainDepartureHour << "\n"
       << " _trainDepartureMinute: " << rhs._trainDepartureMinute << "\n"
       << " _trainBookedTickets: ";
       for(auto i : rhs._trainBookedTickets){
            std::cout << *i << "\n";
       }
       
    return os;
}
