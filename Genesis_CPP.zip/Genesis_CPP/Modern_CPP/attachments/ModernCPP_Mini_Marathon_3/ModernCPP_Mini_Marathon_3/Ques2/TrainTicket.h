#ifndef TRAINTICKET_H
#define TRAINTICKET_H

#include "TicketClass.h"
#include "TicketType.h"
#include <iostream>

class TrainTicket
{
private:

    float _ticketprice;
    TicketType _ticketType;
    TicketClass _ticketClass;
    
public:

    TrainTicket(float ticketprice, TicketType ticketType, TicketClass ticketClass);

    TrainTicket() = delete;
    TrainTicket(const TrainTicket&) = delete;
    TrainTicket(const TrainTicket&&) = delete;
    TrainTicket const operator=(const TrainTicket &) = delete;
    TrainTicket const operator=(const TrainTicket &&) = delete;
    ~TrainTicket() = default;

    float ticketprice() const { return _ticketprice; }
    void setTicketprice(float ticketprice) { _ticketprice = ticketprice; }

    TicketType ticketType() const { return _ticketType; }
    void setTicketType(const TicketType &ticketType) { _ticketType = ticketType; }

    TicketClass ticketClass() const { return _ticketClass; }
    void setTicketClass(const TicketClass &ticketClass) { _ticketClass = ticketClass; }

    friend std::ostream &operator<<(std::ostream &os, const TrainTicket &rhs);

    
};




#endif // TRAINTICKET_H
