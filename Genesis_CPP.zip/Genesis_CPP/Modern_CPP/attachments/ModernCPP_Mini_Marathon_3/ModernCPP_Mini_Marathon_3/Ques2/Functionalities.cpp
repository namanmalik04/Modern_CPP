#include "Functionalities.h"

void CreateObject(TrainContainer &container)
{
    TicketContainer vec;
    vec.push_back(
        std::make_shared<TrainTicket>(
            1234.5f,
            TicketType::GENERAL,
            TicketClass::FIRST
        )
    );

    vec.push_back(
        std::make_shared<TrainTicket>(
            6834.5f,
            TicketType::RESERVED,
            TicketClass::SECOND
        )
    );

    vec.push_back(
        std::make_shared<TrainTicket>(
            5643.5f,
            TicketType::WAITING,
            TicketClass::SLEEPER
        )
    );

    container.push_back(
        std::make_shared<Train>(
            "123","Delhi", "Pune", 10, 30,
            vec
        )
    );


    TicketContainer v;
    v.push_back(
        std::make_shared<TrainTicket>(
            4890.5f,
            TicketType::RESERVED,
            TicketClass::SECOND
        )
    );

    v.push_back(
        std::make_shared<TrainTicket>(
            6784.5f,
            TicketType::WAITING,
            TicketClass::SLEEPER
        )
    );

    container.push_back(
        std::make_shared<Train>(
            "578","Mumbai", "Kolkata", 15, 90,
            v
        )
    );
}

std::vector<Train> FindDepartureTime(TrainContainer &container, int time){
    std::vector<Train> result;

    for(auto i : container){
        if(i->trainDepartureHour() <= time+3){
            result.push_back(*i);
        }
    }

    return result;
}


std::optional<int> TotalTicketPrice(TrainContainer &container, std::string number){
    int total = 0;
    bool flag = false;
    for(auto i : container){
        if(i->trainNumber() == number){
            flag = true;
            for(auto j : i->trainBookedTickets()){
                total += j->ticketprice();
            }
        }
    }

    if(!flag){
        return std::nullopt;
    }

    return total;
}


std::optional<Train> FindTrainStartingStation(TrainContainer &container, std::string number){
    int total = 0;

    for(auto i : container){
        if(i->trainNumber() == number and i->trainDepartureHour() == 15 or i->trainDepartureHour() == 16){
            for(auto j : i->trainBookedTickets()){
                total += j->ticketprice();
            }

            if(total >= 2000){
                return *i;
            }
        }
    }

    return std::nullopt;
}