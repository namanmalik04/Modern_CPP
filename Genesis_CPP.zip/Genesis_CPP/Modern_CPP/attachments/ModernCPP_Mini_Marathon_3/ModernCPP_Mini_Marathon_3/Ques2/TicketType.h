#ifndef TICKETTYPE_H
#define TICKETTYPE_H

enum class TicketType{
    RESERVED,
    WAITING,
    GENERAL
};

#endif // TICKETTYPE_H
