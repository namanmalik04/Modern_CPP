#include "Functionalities.h"

void MakeLambda(int n,std::vector<int>&inpVec,LambdaContainer & lContainer){

 auto f1 = [](int n,std::vector<int>&inpVec){
        std::cout << "First n positive numbers are : ";

        std::lock_guard<std::mutex>lg(mt);

        for(int i = 0; i < n; ++i){
            std :: cout << i+1 << " ";
        }

        std::cout << "\n";

    };

    auto f2 = [](int n,std::vector<int>&inpVec){

        std::cout << "All even no are : ";

        std::lock_guard<std::mutex>lg(mt);

        for(int i = 0; i < n; ++i){

            if(inpVec[i]%2 == 0) 
                std :: cout << inpVec[i] << " ";
        }

        std::cout << "\n";
    };

   

     auto f3 = [](int n,std::vector<int>&inpVec){
        std::vector<int>result;

        std::cout << "Square of first five n number : ";

        std::lock_guard<std::mutex>lg(mt);

        for(int i = 0; i < n; ++i){
            result.push_back(inpVec[i] * inpVec[i]);
        }

        for(int i = 0; i < n; ++i){
            std :: cout << result[i] << " ";
        }

        std::cout << "\n";
    };

     auto f4 = [](int n,std::vector<int>&inpVec){
        std::vector<int>result;

        std::cout << "Cube of first five n number : ";

        std::lock_guard<std::mutex>lg(mt);

        for(int i = 0; i < n; ++i){
            result.push_back(inpVec[i] * inpVec[i] * inpVec[i]);
        }

        for(int i = 0; i < n; ++i){
            std :: cout << result[i] << " ";
        }

        std::cout << "\n";
    };

    lContainer.push_back(f1);
    lContainer.push_back(f2);
    lContainer.push_back(f3);
    lContainer.push_back(f4);

}



void CreateThreads(LambdaContainer &lContainer,int n,std::vector<int>&inputVec){

    std::array<std::thread,4>threadContainer;

    auto itr = lContainer.begin();

    for(auto &th : threadContainer){
        th = std::thread((*itr),std::ref(n),std::ref(inputVec));
        itr++;
    }


    for(auto &th : threadContainer){
        if(th.joinable()){
            th.join();
        }
    }
}


void AsyncFunctionality(int n){
    std::array<int,5>result;
    int j = 0;

    for(int i = n; i < n + 5; ++i)
        result[j++] = i;

    std::cout << "First five number starting from n : ";

    for(int i = 0; i < 5; ++i){
        std::cout << result[i] << " ";
    }
}


