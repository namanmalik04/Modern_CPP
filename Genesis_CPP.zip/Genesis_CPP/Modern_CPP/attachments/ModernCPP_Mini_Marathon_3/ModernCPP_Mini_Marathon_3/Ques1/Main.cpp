#include "Functionalities.h"

int main(){

    int n;
    std::cout << "Enter n : ";
    std::cin >> n;
    std::vector<int>inputVec(n);

    std::cout << "Enter elements : ";
    for(auto &i : inputVec){
        std::cin >> i;
    }

    LambdaContainer lContainer;

    MakeLambda(n,inputVec,lContainer);
    CreateThreads(lContainer,n,inputVec);


    std::future<void> ft = std::async(std::launch::async,AsyncFunctionality,std::ref(n));

    
    return 0;
}