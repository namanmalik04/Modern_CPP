#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H


#include <iostream>
#include <vector>
#include <thread>
#include<future>
#include <array>
#include <functional>
#include <mutex>


std::mutex mt;

using LambdaContainer = std::vector<std::function<void(int,std::vector<int>&)>>;

void MakeLambda(int n,std::vector<int>&inpVec,LambdaContainer & lContainer);

void CreateThreads(LambdaContainer &lContainer,int n,std::vector<int>&inputVec);

void AsyncFunctionality(int n);

#endif // FUNCTIONALITIES_H
