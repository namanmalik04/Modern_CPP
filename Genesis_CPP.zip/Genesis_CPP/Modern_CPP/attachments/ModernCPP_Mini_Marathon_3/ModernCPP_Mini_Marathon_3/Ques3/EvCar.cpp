
#include "EvCar.h"

EvCar::EvCar(int id, ChasisType chasisType, float batteryCapacity) : 
_id(id), _chasisType(chasisType), _batteryCapacity(batteryCapacity) {}


std::ostream &operator<<(std::ostream &os, const EvCar &rhs) {
    os << "_id: " << rhs._id << "\n"
       << " _chasisType: " << static_cast<int>(rhs._chasisType)<< "\n"
       << " _batteryCapacity: " << rhs._batteryCapacity <<"\n";
    return os;
}
