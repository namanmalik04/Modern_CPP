#ifndef ICECAR_H
#define ICECAR_H

#include "FuelType.h"
#include <ostream>

class ICECar
{
private:
    int _id;
    FuelType _fuelType;
    int _fuelTankCapacity;

public:

    ICECar(int id, FuelType fuelType, int fuelTankCapacity);
    ICECar() = delete;
    ICECar(const ICECar&) = default;
    ICECar(const ICECar&&) = delete;
    ICECar  const operator=(const ICECar &) = delete;
    ICECar  const operator=(const ICECar &&) = delete;
    ~ICECar() = default;

    int id() const { return _id; }
    void setId(int id) { _id = id; }

    FuelType fuelType() const { return _fuelType; }
    void setFuelType(const FuelType &fuelType) { _fuelType = fuelType; }

    int fuelTankCapacity() const { return _fuelTankCapacity; }
    void setFuelTankCapacity(int fuelTankCapacity) { _fuelTankCapacity = fuelTankCapacity; }

    friend std::ostream &operator<<(std::ostream &os, const ICECar &rhs);

};



#endif // ICECAR_H
