#include "Functionalities.h"

int main(){

    DataContainer data;

    //Functionality 1
    CreateObject(data);


    //Functionality 2
    try{
        std::vector<EvPointer>ans = FirstNInstances(data,3,ChasisType::LADDER);

        for(auto i : ans){
            std::cout << *i << "\n";
        }
    }
    catch(DataEmptyException &e){
        std::cout << e.what() << "\n\n";
    }
    catch(InvalidNthInstance &e){
        std::cout << e.what() << "\n\n";
    }


    //Functionality 3
    try{
        if(bool ans = FindCapacity(data); ans){
            std::cout << "All Ice Car Have tank capacity above 30 \n";
        }
        else{
            std::cout << "All Ice Car Don't Have tank capacity above 30 \n";
        }
    }
    catch(DataEmptyException &e){
        std::cout << e.what() << "\n\n";
    }


    //Functionality 4
    try{

        if(int count = CountEv(data); count > 0){
            std::cout << "Number of Ev car : " << count << "\n";
        }
        else{
            std::cout << "Data has No Ev car\n";
        }
    
    }
    catch(DataEmptyException &e){
        std::cout << e.what() << "\n\n";
    }


    //Functionality 5
    if(std::optional<ChasisType> ct = FindChasisType(data,123); ct.has_value()){
        if(static_cast<int>(ct.value()) == 0){
            std::cout << "chasis Type : LADDER\n";
        }
        else{
             std::cout << "chasis Type : TUBULAR\n";
        }
    }
    else{
        std::cout << "No Car found with given id\n";
    }


    //Functionality 6
    try{

        if(int total = TotalBatteryCapacity(data); total > 0){
            std::cout << "Total Battery capacity of Ev car : " << total << "\n";
        }
        else{
            std::cout << "Data has No Ev car\n";
        }
    
    }
    catch(DataEmptyException &e){
        std::cout << e.what() << "\n\n";
    }



    //Functionality 7
    try{
        NthInstance(data,2);
    }
    catch(DataEmptyException &e){
        std::cout << e.what() << "\n\n";
    }
    catch(InvalidNthInstance &e){
        std::cout << e.what() << "\n\n";
    }



    return 0;
}