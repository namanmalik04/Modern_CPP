#ifndef EVCARTYPE_H
#define EVCARTYPE_H

enum class ChasisType{
    LADDER,
    TUBULAR
};

#endif // EVCARTYPE_H
