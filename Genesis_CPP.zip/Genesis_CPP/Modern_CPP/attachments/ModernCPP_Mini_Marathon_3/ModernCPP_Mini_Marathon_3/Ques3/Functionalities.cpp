#include "Functionalities.h"

void CreateObject(DataContainer &data)
{
    data.push_back(
        std::make_shared<EvCar>(
            123,ChasisType::LADDER, 25.5f
        )
    );

    data.push_back(
        std::make_shared<ICECar>(
            567,FuelType::DIESEL, 30
        )
    );

    data.push_back(
        std::make_shared<EvCar>(
            876,ChasisType::TUBULAR, 15.5f
        )
    );

    data.push_back(
        std::make_shared<ICECar>(
            932,FuelType::PETROL, 45
        )
    );
}


std::vector<EvPointer>FirstNInstances(DataContainer &data,int n,ChasisType chasisType){

    if(data.empty()) throw DataEmptyException("Data not found !");


    int size = 0;

    

    std::vector<EvPointer>res;

    for(auto i : data){
        if(std::holds_alternative<EvPointer>(i) and std::get<EvPointer>(i)->chasisType() == chasisType){
            res.push_back(std::get<EvPointer>(i));
            size++;

            if(size == n){
                break;
            }
        }
    }

    if(size < n) throw InvalidNthInstance("3 instance not available");
   return res;
}

bool FindCapacity(DataContainer &data){

    if(data.empty()) throw DataEmptyException("Data not found !");

    for(auto i : data){
        if(std::holds_alternative<ICEPointer>(i)){
            if(std::get<ICEPointer>(i)->fuelTankCapacity() < 30){
                return false;
            }
        }
    }

    return true;
}

int CountEv(DataContainer &data){

    if(data.empty()) throw DataEmptyException("Data not found !");

    int count = 0;

    for(auto i : data){
        if(std::holds_alternative<EvPointer>(i)){
            count++;
        }
    }

    return count;
}


std::optional<ChasisType> FindChasisType(DataContainer &data,int id){
    if(data.empty()) throw DataEmptyException("Data not found !");


    for(auto i : data){
        if(std::holds_alternative<EvPointer>(i) and std::get<EvPointer>(i)->id() == id){
            return std::get<EvPointer>(i)->chasisType();
        }
    }

    return std::nullopt;



}


int TotalBatteryCapacity(DataContainer &data){
    if(data.empty()) throw DataEmptyException("Data not found !");

    int total = 0;
    for(auto i : data){
        if(std::holds_alternative<EvPointer>(i)){
            total += std::get<EvPointer>(i)->batteryCapacity();
        }
    }

    return total;
}


void NthInstance(DataContainer &data,int n){

    if(data.empty()) throw DataEmptyException("Data not found !");
    
    for(auto i : data){
        n--;

        if(n == 0){

            
            if(std::holds_alternative<EvPointer>(i)){
                std::cout << "Nth istance is EvClass : ";
                std::cout << *(std::get<EvPointer>(i)) << "\n";
            }
            else{
                std::cout << "Nth istance is ICEClass : ";
                std::cout << *(std::get<ICEPointer>(i)) << "\n";
            }
        }
    }

    if(n > 0)
        throw InvalidNthInstance("N th instance not found");
}