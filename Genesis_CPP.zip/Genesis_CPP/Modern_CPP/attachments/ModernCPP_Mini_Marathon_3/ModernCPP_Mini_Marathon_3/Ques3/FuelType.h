#ifndef ICECARTYPE_H
#define ICECARTYPE_H

enum class FuelType{
    PETROL,
    DIESEL
};

#endif // ICECARTYPE_H
