#ifndef EVCAR_H
#define EVCAR_H

#include <memory>
#include "ChasisType.h"
#include <iostream>

class EvCar
{
private:

    int _id;
    ChasisType _chasisType;
    float _batteryCapacity;

    
public:
    EvCar() = delete;
    EvCar(int id, ChasisType chasisType, float batteryCapacity);
    EvCar(const EvCar&) = default;
    EvCar(const EvCar&&) = delete;
    EvCar  const operator=(const EvCar &) = delete;
    EvCar  const operator=(const EvCar &&) = delete;
    ~EvCar() = default;

    int id() const { return _id; }
    void setId(int id) { _id = id; }

    ChasisType chasisType() const { return _chasisType; }
    void setChasisType(const ChasisType &chasisType) { _chasisType = chasisType; }

    float batteryCapacity() const { return _batteryCapacity; }
    void setBatteryCapacity(float batteryCapacity) { _batteryCapacity = batteryCapacity; }

    friend std::ostream &operator<<(std::ostream &os, const EvCar &rhs);

    
};




#endif // EVCAR_H
