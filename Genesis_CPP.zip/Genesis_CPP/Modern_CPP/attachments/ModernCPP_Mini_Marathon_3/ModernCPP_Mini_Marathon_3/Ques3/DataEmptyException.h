#ifndef EXCEPTION_H
#define EXCEPTION_H


#include <stdexcept>
#include <cstring>

class DataEmptyException
{
private:
    char *_msg;
public:

    DataEmptyException(const char *msg){
        _msg = new char[strlen(msg) + 1];
        strcpy(_msg,msg);
    }
    DataEmptyException() = delete;
    DataEmptyException(const DataEmptyException&) = delete;
    DataEmptyException(const DataEmptyException&&) = delete;
    DataEmptyException const operator=(const DataEmptyException &) = delete;
    DataEmptyException const operator=(const DataEmptyException &&) = delete;
    ~DataEmptyException() = default;

    virtual char * what(){
        return _msg;
    }
};


#endif // EXCEPTION_H
