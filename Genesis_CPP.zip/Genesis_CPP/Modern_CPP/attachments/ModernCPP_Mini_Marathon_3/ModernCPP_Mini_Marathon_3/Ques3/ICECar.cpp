#include "ICECar.h"

ICECar::ICECar(int id, FuelType fuelType, int fuelTankCapacity) :
_id(id), _fuelType(fuelType), _fuelTankCapacity(fuelTankCapacity) {}

std::ostream &operator<<(std::ostream &os, const ICECar &rhs) {
    os << "_id: " << rhs._id << "\n"
       << " _fuelType: " << static_cast<int>(rhs._fuelType) << "\n"
       << " _fuelTankCapacity: " << rhs._fuelTankCapacity << "\n"; 
    return os;
}
