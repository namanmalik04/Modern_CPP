#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H
#include <memory>
#include "EvCar.h"
#include "ICECar.h"
#include <vector>
#include <variant>
#include "DataEmptyException.h"
#include "InvalidNthInstance.h"
#include <optional>


using EvPointer = std::shared_ptr<EvCar>;
using ICEPointer = std::shared_ptr<ICECar>;
using DataContainer = std::vector<std::variant<EvPointer,ICEPointer>>;

void CreateObject(DataContainer &data);

std::vector<EvPointer>FirstNInstances(DataContainer &data,int n,ChasisType chasisType);

bool FindCapacity(DataContainer &data);

int CountEv(DataContainer &data);

std::optional<ChasisType> FindChasisType(DataContainer &data,int id);

int TotalBatteryCapacity(DataContainer &data);

void NthInstance(DataContainer &data,int n);

#endif // FUNCTIONALITIES_H
