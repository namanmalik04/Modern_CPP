#ifndef INVALIDNTHINSTANCE_H
#define INVALIDNTHINSTANCE_H

#include <stdexcept>
#include <cstring>

class InvalidNthInstance
{
private:
    char *_msg;
public:

    InvalidNthInstance(const char *msg){
        _msg = new char[strlen(msg) + 1];
        strcpy(_msg,msg);
    }
    InvalidNthInstance() = delete;
    InvalidNthInstance(const InvalidNthInstance&) = delete;
    InvalidNthInstance(const InvalidNthInstance&&) = delete;
    InvalidNthInstance const operator=(const InvalidNthInstance &) = delete;
    InvalidNthInstance const operator=(const InvalidNthInstance &&) = delete;
    ~InvalidNthInstance() = default;

    virtual char * what(){
        return _msg;
    }
};

#endif // INVALIDNTHINSTANCE_H
