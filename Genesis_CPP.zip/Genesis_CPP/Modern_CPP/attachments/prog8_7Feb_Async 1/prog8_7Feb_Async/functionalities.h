#include <iostream>
#include <vector>
#include <functional>

using fnType = std::function<int(std::vector<int> &data)>;
using FnContainer = std::vector<fnType>;
using DataContainer = std::vector<int>;

// void op(FnContainer& fns,DataContainer& data);
void MakeLambda(FnContainer &data);

// extern fnType f1;
// extern fnType f2;
// extern fnType f3;
