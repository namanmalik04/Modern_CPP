#include <iostream>
#include <vector>
#include "functionalities.h"

void MakeLambda(FnContainer &fns)
{
    auto f1 = [](std::vector<int> &data) -> int
    {
        if (data.empty())
        {
            throw std::runtime_error("data is empty....");
        }
        return data.front();
    };
    auto f2 = [](std::vector<int> &data) -> int
    {
        if (data.empty())
        {
            throw std::runtime_error("data is empty....");
        }
        return data.back();
    };
    auto f3 = [](std::vector<int> &data) -> int
    {
        if (data.empty())
        {
            throw std::runtime_error("data is empty....");
        }
        int total = 0.0f;
        for (int val : data)
        {
            total += val;
        }
        return total;
    };
    // std::vector<fnType> fn{f1,f2,f3};
    fns.emplace_back(f1);
    fns.emplace_back(f2);
    fns.emplace_back(f3);
}

// COMMON ERRORS
/*undefined declaration to main()
main() not made

# undefined declaration to calTax() due to following ;
all the cpp files compiled does not have .h files containing calTax().
or siganture may be missing
or body may be missing     (undefined ref from loader is not able to load the func)

#too few arguments when u have passed less no. than required

        void xyz(int a,double b,char c){

        }

        xyz(10,'z',20.0);          //though types are not matching. We are not getting any error coz here implicit type conversion ['z' converts into double, 20.0 into char]

# can not convert something into something {parameter may be wrong}
# Obj is instantiated but not assigned
smart ptr conversion from rhs to lhs type

*/
