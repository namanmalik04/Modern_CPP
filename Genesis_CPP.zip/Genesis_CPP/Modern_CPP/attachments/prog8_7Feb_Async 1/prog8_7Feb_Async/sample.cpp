#include "functionalities.h"

void op(FnContainer &fns, DataContainer &data)
{
    for (fnType fn : fns)
    {
        std::cout << fn(data) << " ";
    }
    std::cout << "\n";
}

int main()
{
    FnContainer fns;
    std::vector<int> data{10, 20, 30, 40, 50};
    try
    {
        MakeLambda(fns);
    }
    catch (const std::exception &e)
    {
        std::cerr << e.what() << '\n';
    }

    op(fns, data);

    std::vector<int> dummydata{1, 2, 3};
    auto bindedOperation = std::bind(op, std::placeholders::_1, std::ref(dummydata));
    bindedOperation(fns);
}
