#include "Functionalities.h"
#include <iostream>
#include <thread>
#include <array>
#include <future>
using namespace std;
int main()
{
    MapContainer data;
    AccountPointerContainer accounts;
    // std::array<std::thread,5> threadsArr;
    std::future<void> r1 = std::async(std::launch::async, CreateObjects, std::ref(data), std::ref(accounts));
    r1.wait();

    // CreateObjects(data,accounts);
    try
    {
        std::future<float> r2 = std::async(std::launch::async, FindTotalBalance, std::ref(data));
        std::cout << "Total Balance: " << r2.get() << "\n";

        std::future<unsigned int> r3 = std::async(std::launch::async, CountAbove50000BalanceAccounts, std::ref(data));
        std::cout << "Count of above 50000 in account balance are: " << r3.get() << "\n";

        std::future<bool> r4 = std::async(std::launch::async, IsAnyAccountWithNoCard, std::ref(data));
        bool flag = r4.get();
        if (flag)
            std::cout << "At least one account with null card exists" << "\n";
        
        else
            std::cout << "No such account exists\n";

        std::future<std::optional<float>> r5 = std::async(std::launch::async, FindBalanceById, std::ref(data), 87689240L);

        std::optional<float> result = r5.get();

        if (result.has_value())
            std::cout << "Account Found with Balance: " << result.value() << "\n";

        else
            std::cout << "Account not found";
    }
    catch (const std::exception &e)
    {
        std::cerr << e.what() << '\n';
    }

    return 0;
}

// RULE1:
// Create objects thread should be done before any other threads

// RULE2:
// Match the return type of the future to the return type of the function

// RULE3:
// don't use get() more than once, if u want to call many times ..store it into a variable;
