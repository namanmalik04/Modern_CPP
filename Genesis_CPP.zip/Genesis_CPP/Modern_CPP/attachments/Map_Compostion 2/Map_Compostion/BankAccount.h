#ifndef BANKACCOUNT_H
#define BANKACCOUNT_H
#include<string>
#include"AccountType.h"
#include<memory>
#include"DebitCard.h"

using CardPointer = std::shared_ptr<DebitCard>;
class BankAccount
{
private:
    static int _counter;//private variables --->  to prevent accidental modification or human errors
    const unsigned long _accountNumber;
    std::string _accountHolderName;
    AccountType _accountType;
    float _accountBalance;
    CardPointer _accountDebitCard;
public:
    BankAccount()= delete;
    BankAccount(const BankAccount&)=delete;
    BankAccount& operator=(const BankAccount&) = delete;
    BankAccount(BankAccount&&) = delete;
    BankAccount& operator=(BankAccount&&) = delete;
    ~BankAccount() = default;

    BankAccount(std::string accountHolderName,AccountType accountType, float accountBalance);
    BankAccount(std::string accountHolderName,AccountType accountType, float accountBalance,CardPointer accountDebitCard);
    

    void DepositAmount(long amount);
    void WithdrawAmount(long amount);

    unsigned long accountNumber() const { return _accountNumber; }
    std::string accountHolderName() const { return _accountHolderName; }
    void setAccountHolderName(const std::string &accountHolderName) { _accountHolderName = accountHolderName; }
    AccountType accountType() const { return _accountType; }
    
    void setAccountType(const AccountType &accountType) { _accountType = accountType; }

    CardPointer accountDebitCard() const { return _accountDebitCard; }
    void setAccountDebitCard(const CardPointer &accountDebitCard) { _accountDebitCard = accountDebitCard; }

    float accountBalance() const { return _accountBalance; }
};
inline int BankAccount::_counter=9000000;//intialization

#endif // BANKACCOUNT_H
