#include "Functionalities.h"
#include <numeric>

void CreateObjects(MapContainer &data, AccountPointerContainer &accounts)
{
    accounts.emplace_back(make_shared<BankAccount>("Poojitha",
                                                   AccountType::SAVINGS,
                                                   100.0f,
                                                   std::make_shared<DebitCard>(111,
                                                                               88677767889L,
                                                                               "09/27",
                                                                               DebitCardType::MASTERCARD)));
    accounts.emplace_back(make_shared<BankAccount>("Abhisek",
                                                   AccountType::SAVINGS,
                                                   80.0f,
                                                   std::make_shared<DebitCard>(123,
                                                                               88699967889L,
                                                                               "10/27",
                                                                               DebitCardType::VISA)));
    accounts.emplace_back(make_shared<BankAccount>("Aditya",
                                                   AccountType::PENSION,
                                                   900.0f,
                                                   std::make_shared<DebitCard>(156,
                                                                               886999687689L,
                                                                               "11/27",
                                                                               DebitCardType::RUPAY)));
    // g++ -c file_name : for moving
    // we can't send lvalue reference to make_pair so we pass by sending the rvalue reference to make_pair<> by using move operator
    data.emplace(make_pair<unsigned long, AccountPointer>(accounts[0]->accountNumber(), std::move(accounts[0])));
    data.emplace(make_pair<unsigned long, AccountPointer>(accounts[1]->accountNumber(), std::move(accounts[1])));
    data.emplace(make_pair<unsigned long, AccountPointer>(accounts[2]->accountNumber(), std::move(accounts[2])));
}

/*
    map<key, object>
    create a key, create an object -----> move them into a pair -----> pair moves into hashtable
    step 1 : create the object, preserve its lifetime in some sort fo data container (not hashtable) otherwise key will be same for
    each object due to static keyword
*/

float FindTotalBalance(const MapContainer &data)
{
    if (data.empty())
        std::runtime_error("Data not available");
    
    float ans = std::accumulate(
        data.begin(),
        data.end(),
        0.0f,
        [](float total, std::pair<unsigned long, AccountPointer> &&p)
        {
            return total + p.second->accountBalance();
        });
    return ans;
}

unsigned int CountAbove50000BalanceAccounts(const MapContainer &data)
{
    if (data.empty())
    {
        std::runtime_error("Data not available");
    }
    size_t count = std::count_if(
        data.begin(),
        data.end(),
        [](std::pair<unsigned long, AccountPointer> &&p)
        {
            return p.second->accountBalance() > 50000.0f;
        });
    return count;
}

bool IsAnyAccountWithNoCard(const MapContainer &data)
{
    if (data.empty())
        std::runtime_error("Data not available");
    
    bool ans = std::any_of(
        data.begin(),
        data.end(),
        [](std::pair<unsigned long, AccountPointer> &&p)
        {
            return p.second->accountDebitCard() == nullptr;
        });

    return false;
}

std::optional<float> FindBalanceById(const MapContainer &data, unsigned long accNumber)
{
    if (data.empty())
        std::runtime_error("Data not available");

    
    auto itr = std::find_if(
        data.begin(),
        data.end(),
        [&](std::pair<unsigned long, AccountPointer> &&p)
        {
            return p.second->accountNumber() == accNumber;
        });

    if (itr == data.end())
        return std::nullopt;

    return (*itr).second->accountBalance();
}
