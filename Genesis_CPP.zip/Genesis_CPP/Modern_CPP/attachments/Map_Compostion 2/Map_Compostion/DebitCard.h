#ifndef DEBITCARD_H
#define DEBITCARD_H
#include<string>
#include"DebitCardType.h"
class DebitCard
{
private:
    unsigned short _cvv;
    long _cardNumber;
    std::string&& _expiryDate;// a const lvalue reference it can attach both to lvalue and rvalue, lvalue is accecpted by reference
    DebitCardType _cardType;
public:

    DebitCard()= delete;

    DebitCard(const DebitCard&)=delete;

    DebitCard& operator=(const DebitCard&) = delete;

    DebitCard(DebitCard&&) = delete;

    DebitCard& operator=(DebitCard&&) = delete;

    ~DebitCard() = default;

    DebitCard(unsigned short cvv, long cardNumber , std::string&& expiryDate);
    DebitCard(unsigned short cvv, long cardNumber , std::string&& expiryDate, DebitCardType cardType);


    long cardNumber() const { return _cardNumber; }

    DebitCardType cardType() const { return _cardType; }

    std::string expiryDate() const { return _expiryDate; }

    unsigned short cvv() const { return _cvv; }
};





#endif // DEBITCARD_H
