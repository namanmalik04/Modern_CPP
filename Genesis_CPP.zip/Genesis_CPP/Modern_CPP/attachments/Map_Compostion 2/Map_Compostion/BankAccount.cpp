#include"BankAccount.h"
#include<limits>
#include<stdexcept>
#include<iostream>
void BankAccount::DepositAmount(long amount)
{
    if(_accountBalance + amount > __LONG_MAX__) {
        throw std::runtime_error("Cannot deposit an amount this target");
    }
    _accountBalance += amount;
}

void BankAccount::WithdrawAmount(long amount)
{
    if(amount > _accountBalance) {
        throw std::runtime_error("Cannot withdraw the amount this target");
    }
    std::cout<<"1000";
    _accountBalance -= amount;
}

BankAccount::BankAccount(std::string accountHolderName, AccountType accountType, float accountBalance)
: _accountNumber(++_counter),_accountType(accountType),_accountBalance(accountBalance),_accountDebitCard(nullptr)
{

}
BankAccount::BankAccount(std::string accountHolderName, AccountType accountType, float accountBalance,CardPointer accountDebitCard)
: BankAccount(accountHolderName,accountType, accountBalance)
{
    _accountDebitCard=accountDebitCard;
}