#ifndef ACCOUNTTYPE_H
#define ACCOUNTTYPE_H

enum class AccountType {
    SAVINGS,
    CURRENT,
    PENSION
};


#endif // ACCOUNTTYPE_H
