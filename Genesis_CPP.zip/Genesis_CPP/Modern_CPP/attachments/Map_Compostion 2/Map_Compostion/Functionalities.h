#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H
#include <algorithm>
#include <vector>
#include "BankAccount.h"
#include <string>
#include <optional>
#include <unordered_map>
using namespace std;

using AccountPointer = shared_ptr<BankAccount>;
using MapContainer = std::unordered_map<unsigned long, AccountPointer>;
using AccountPointerContainer = vector<AccountPointer>;



void CreateObjects(MapContainer &data, AccountPointerContainer &p);


float FindTotalBalance(const MapContainer &data);
// returns the total balance of all the accounts
unsigned int CountAbove50000BalanceAccounts(const MapContainer &data);
// return all accounts which has the balance of greater than 50000
bool IsAnyAccountWithNoCard(const MapContainer &data);
/*
    return the cvv number of the debit card attached with the account with max balance of multiple such max
    accounts exist, return the first match found
*/
std::optional<float> FindBalanceById(const MapContainer &data, unsigned long accNumber);

#endif // FUNCTIONALITIES_H
