#ifndef DEBITCARDTYPE_H
#define DEBITCARDTYPE_H

enum class DebitCardType {
    VISA,
    MASTERCARD,
    RUPAY
};

#endif // DEBITCARDTYPE_H
