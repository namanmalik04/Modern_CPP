#ifndef DEVELOPER_H
#define DEVELOPER_H
#include"SkillSet.h"
#include<string>
#include<iostream>
#include<vector>
using namespace std;
class Developer
{
private:
    string _id;
    string _name;
    float _salary;
    int _experience_years;
    vector<SkillSet> _skill;

public:
    Developer()=default;
    ~Developer()=default;
    Developer(string id, string name, float salary, int experience_years, vector<SkillSet> skill);

    //GETTERS
    string id() const { return _id; }
    string name() const { return _name; }
    int experienceYears() const { return _experience_years; }
    vector<SkillSet> skill() const { return _skill; }
    float salary() const { return _salary; }

    //MEMBER FUNCTIONS
    float CalculateBonus();

    //OVERLOADED OPERATORS
    friend std::ostream &operator<<(std::ostream &os, const Developer &rhs);
};

#endif // DEVELOPER_H
