#include "Functionalities.h"
#include <future>
#include"EmptyContainerException.h"
#include <thread>
int main()
{
    Container data;

    // CREATE OBJECTS
    future<void> r1 = async(launch::async, CreateObjects, ref(data));
    r1.get();

    //FIND INSTANCES > 5000 SAL
    try
    {
        future<optional<Container>> r2 = async(launch::async, FindInstancesAbove5Exp, ref(data));
        optional<Container> result = r2.get();
        
        if (result.has_value())
        {
            cout << "The Details of employees above 5 yrs experience" << endl;
            for (auto &i : result.value())
            {
                visit([](auto &&val)
                    { cout << *val << endl; },
                    i);
            }
            cout << endl;
        }   
    }
    catch(EmptyContainerException& e)
    {
        cout<< e.what() << '\n';
    }
    
    //CALCULATE AVERAGE
    try
    {
        future<optional<float>> r3 = async(launch::async, CalAvgSal, ref(data));
        optional<float> Avg = r3.get();
        if (Avg.has_value())
            cout << "The average salary of Code Testers is : " << Avg.value() << endl;
        
    }
    catch(EmptyContainerException& e)
    {
        cout<< e.what() << '\n';
    }

    //FIND MATCHING SKILLS
    try
    {
        string id;
        cout << "Enter the id whose skillset you want to find ";
        cin >> id;
        future<optional<vector<SkillSet>>> r4 = async(launch::async, FindSkillWithId, ref(data), ref(id));
        optional<vector<SkillSet>> skills = r4.get();
        if (skills.has_value())
        {
            cout<<"The skills are as follows : ";
            for (SkillSet i : skills.value())
            {
                if (static_cast<int>(i) == 0)
                    cout << "CODING" << " ";
                else if (static_cast<int>(i) == 1)
                    cout << "UNIT_TESTTING" << " ";
                else if (static_cast<int>(i) == 2)
                    cout << "CODE_REVIEW" << " ";
                else if (static_cast<int>(i) == 3)
                    cout << "INTEGRATION_TESTING" << " ";
            }
        } 
    }
    catch(EmptyContainerException& e)
    {
        cout<< e.what() << '\n';
    }


    //CHECK EMPLOYEE WHOSE SALARY IS > 60000
    try
    {
        future<bool> r5 = async(launch::async, CheckEmployyeAbove60000, ref(data));
        bool present = r5.get();
        if (present)
            cout << "There are employees whose sal > 60000" << endl;
        else
            cout << "There are no employees whose sal > 60000" << endl;
        
    }
    catch(EmptyContainerException& e)
    {
        cout<< e.what() << '\n';
    }


    //FIND MATCHING BONUS
    try
    {
        string i;
        cout << "Enter the id whose bonus you want to find : ";
        cin >> i;
        future<optional<float>> r6 = async(launch::async, ReturnCalBonus, ref(data), ref(i));
        optional<float> bonus = r6.get();
        if(bonus.has_value())
            cout << "The employee's bonus is : " << bonus.value();       
    }
    catch(EmptyContainerException& e)
    {
        cout<< e.what() << '\n';
    }

    return 0;
}