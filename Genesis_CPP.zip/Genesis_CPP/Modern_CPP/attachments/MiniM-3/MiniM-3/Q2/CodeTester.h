#ifndef CODETESTER_H
#define CODETESTER_H
#include<string>
#include<iostream>
#include"SkillSet.h"
#include<vector>
using namespace std;
class CodeTester
{
private:
    string _id;
    string _name;
    float _salary;
    int _experience_years;
    vector<SkillSet> _skills;

public:
    CodeTester() =default;
    ~CodeTester() =default;
    CodeTester(string id, string name,float salary, int experience_years, vector<SkillSet> skill);
    
    //GETTERS
    string id() const { return _id; }
    string name() const { return _name; }
    float salary() const { return _salary; }
    int experienceYears() const { return _experience_years; }
    vector<SkillSet> skills() const { return _skills; }

    //OVERLOADED OPERATORS
    friend std::ostream &operator<<(std::ostream &os, const CodeTester &rhs);

    //MEMBER FUNCTIONS
    float CalculateBonus();
    
    
};

#endif // CODETESTER_H
