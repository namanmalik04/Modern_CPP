#include<iostream>
#include<vector>
#include<memory>
#include<variant>
#include<optional>
#include"CodeTester.h"
#include"Developer.h"
using namespace std;

using CPointer = shared_ptr<CodeTester>;
using DPointer = shared_ptr<Developer>;

using Container = vector<variant<CPointer,DPointer>>;

void CreateObjects(Container& data);

optional<Container> FindInstancesAbove5Exp(Container& data);
optional<float> CalAvgSal(Container& data);
optional<vector<SkillSet>> FindSkillWithId(Container& data, string id);
bool CheckEmployyeAbove60000(Container& data);
optional<float> ReturnCalBonus(Container& data, string id);

