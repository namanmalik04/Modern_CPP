#include "CodeTester.h"

std::ostream &operator<<(std::ostream &os, const CodeTester &rhs)
{
    os << "_id: " << rhs._id << endl
       << " _name: " << rhs._name << endl
       << " _salary: " << rhs._salary << endl
       << " _experience_years: " << rhs._experience_years << endl;

    for (SkillSet i : rhs._skills)
        os << "skills" << static_cast<int>(i);
    
    os<<endl;
    return os;
}
float CodeTester::CalculateBonus()
{
    if (this->experienceYears() < 5)
        return 0.05f * this->salary();

    else if (this->experienceYears() > 5)
        return 0.1f * this->salary();

    else
        return 0.0f;
}

CodeTester::CodeTester(string id, string name,float salary, int experience_years, vector<SkillSet> skills)
:_id(id), _name(name), _salary(salary), _experience_years(experience_years),_skills(skills)
{

}





