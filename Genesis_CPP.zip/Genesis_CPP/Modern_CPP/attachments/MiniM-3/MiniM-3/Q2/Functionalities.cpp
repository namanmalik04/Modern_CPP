#include "Functionalities.h"
#include"EmptyContainerException.h"
void CreateObjects(Container &data)
{
    vector<SkillSet> v1 {SkillSet::CODE_REVIEW, SkillSet::CODING, SkillSet::INTEGRATION_TESTING};
    vector<SkillSet> v2 {SkillSet::CODE_REVIEW, SkillSet::CODING, SkillSet::UNIT_TESTTING};
    vector<SkillSet> v3 {SkillSet::UNIT_TESTTING, SkillSet::CODING, SkillSet::INTEGRATION_TESTING};

    DPointer dp1 = make_shared<Developer>("1", "Abhisek", 80000.0f, 3, v1);
    DPointer dp2 = make_shared<Developer>("2", "Abhijeet", 100000.0f, 8, v2);
    DPointer dp3 = make_shared<Developer>("3", "Aman", 50000.0f, 6, v3);

    CPointer cp1 = make_shared<CodeTester>("3", "Animesh", 40000.0f, 6, v1);
    CPointer cp2 = make_shared<CodeTester>("4", "Soumya", 20000.0f, 3, v1);

    data.push_back(dp1);
    data.push_back(dp2);
    data.push_back(dp3);
    data.push_back(cp1);
    data.push_back(cp2);
}

optional<Container> FindInstancesAbove5Exp(Container &data)
{
    Container c;
    if(data.empty())
        throw EmptyContainerException ("The container is empty()");

    for (auto &itr : data)
    {
        if (holds_alternative<DPointer>(itr))
        {
            auto dptr = std::get<DPointer>(itr);
            if (dptr->experienceYears() > 5)
                c.push_back(dptr);
        }
        else if (holds_alternative<CPointer>(itr))
        {
            auto cptr = std::get<CPointer>(itr);
            if (cptr->experienceYears() > 5)
                c.push_back(cptr);
        }
    }
    if (c.empty())
        return nullopt;
    return c;
}

optional<float> CalAvgSal(Container &data)
{
    if(data.empty())
        throw EmptyContainerException ("The container is empty()");
    float sum = 0.0f;
    int count = 0.0;
    for (auto &itr : data)
    {
        if (holds_alternative<CPointer>(itr))
        {
            auto cptr = std::get<CPointer>(itr);
            sum += cptr->salary();
            count++;
        }
    }
    if (sum == 0.0f)
        return nullopt;
    return (float)sum / count;
}

optional<vector<SkillSet>> FindSkillWithId(Container &data, string id)
{
    if(data.empty())
        throw EmptyContainerException ("The container is empty()");
        
    int count = 0;
    for (auto &itr : data)
    {
        if (holds_alternative<CPointer>(itr))
        {
            auto cptr = std::get<CPointer>(itr);
            if (cptr->id() == id)
            {
                count++;
                return cptr->skills();
            }
        }
        else if (holds_alternative<DPointer>(itr))
        {
            auto dptr = std::get<DPointer>(itr);
            if (dptr->id() == id)
            {
                count++;
                return dptr->skill();
            }
        }
    }
    if (count == 0)
        return nullopt;
}

bool CheckEmployyeAbove60000(Container &data)
{
    if(data.empty())
        throw EmptyContainerException ("The container is empty()");
    for (auto &itr : data)
    {
        if (holds_alternative<DPointer>(itr))
        {
            auto dptr = std::get<DPointer>(itr);
            if (dptr->salary() > 60000)
                return true;
        }
        else if (holds_alternative<CPointer>(itr))
        {
            auto cptr = std::get<CPointer>(itr);
            if (cptr->salary() > 60000)
                return true;
        }
    }
    return false;
}
optional<float> ReturnCalBonus(Container &data, string id)
{
    if(data.empty())
        throw EmptyContainerException ("The container is empty()");
    bool flag = 0;
    for (auto &itr : data)
    {
        if (holds_alternative<DPointer>(itr))
        {
            auto dptr = std::get<DPointer>(itr);
            if (dptr->id() == id)
            {
                flag = 1;
                return dptr->CalculateBonus();
            }
        }
        else if (holds_alternative<CPointer>(itr))
        {
            auto cptr = std::get<CPointer>(itr);
            if (cptr->id() == id)
            {
                flag = 1;
                return cptr->CalculateBonus();
            }
        }
    }
    if (flag == 0)
        return nullopt;
}
