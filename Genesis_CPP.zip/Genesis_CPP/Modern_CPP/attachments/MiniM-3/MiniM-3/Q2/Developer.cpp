#include "Developer.h"
std::ostream &operator<<(std::ostream &os, const Developer &rhs)
{
    os << "_id: " << rhs._id << endl
       << " _name: " << rhs._name << endl
       << " _experience_years: " << rhs._experience_years << endl;

    for (SkillSet i : rhs._skill)
        os << "Skills" << static_cast<int>(i) << " ";

    os << endl;
    return os;
}

Developer::Developer(string id, string name, float salary, int experience_years, vector<SkillSet> skill)
    : _id(id), _name(name), _salary(salary), _experience_years(experience_years), _skill(skill)
{
}

float Developer::CalculateBonus()
{
    if (this->experienceYears() < 5)
        return 0.1f * this->salary();

    else if (this->experienceYears() > 5)
        return 0.2f * this->salary();

    else
        return 0.0f;
}
