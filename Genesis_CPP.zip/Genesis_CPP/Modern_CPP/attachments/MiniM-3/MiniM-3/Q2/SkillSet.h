#ifndef SKILLSET_H
#define SKILLSET_H

enum class SkillSet
{
    CODING,
    UNIT_TESTTING,
    CODE_REVIEW,
    INTEGRATION_TESTING
};

#endif // SKILLSET_H
