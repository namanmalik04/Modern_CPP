#include <exception>
#include <cstring>
#include <iostream>
class NoOddNumbers : public std::exception
{
private:
    char *_msg;

public:
    NoOddNumbers() = delete;
    explicit NoOddNumbers(const char *msg)
    {

        _msg = new char[strlen(msg) + 1];
        strcpy(_msg, msg);
    }
    NoOddNumbers(const NoOddNumbers &) = default;
    NoOddNumbers &operator=(const NoOddNumbers &) = default;
    NoOddNumbers(NoOddNumbers &&) = default;
    NoOddNumbers &operator=(NoOddNumbers &&) = delete;
    ~NoOddNumbers() = default;

    char *what()
    {
        return _msg;
    }
};

