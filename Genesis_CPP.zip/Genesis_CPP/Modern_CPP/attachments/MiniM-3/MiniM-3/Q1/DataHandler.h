#ifndef DATAHANDLER_H
#define DATAHANDLER_H
#include<array>
#include<functional>
#include<future>
#include <iostream>
#include<thread>
using namespace std;
class DataHandler
{
private:
    int _data[5];
public:
    DataHandler()=default;
    ~DataHandler()=default;
    DataHandler(int data[]);

    //MEMBER FUNCTIONS
    void FilterData(const function<bool(int)>&);
    void FindNthValue(future<int>& ft);
    void SumOfOdd();

    //GETTERS
    int* data(){ return _data; }
    //void setData(int data) { _data = data; }
 

    //OVERLOADED OPERATORS
    friend std::ostream &operator<<(std::ostream &os, const DataHandler &rhs);
    int operator + (DataHandler& obj);  


};

#endif // DATAHANDLER_H
