#include"DataHandler.h"
#include<functional>
#include<future>
#include <iostream>
#include<condition_variable>
#include<mutex>
#include<thread>
#include"NoOddNumbers.h"

using namespace std;
int main()
{
    auto filter = [](int num)->bool
                {
                    return num%3==0;
                };

    int arr[5] {1,2,3,4,5};
    int brr[5] {6,7,8,9,10};

    DataHandler d1(arr);
    DataHandler d2(brr);
    
    //FILTERING DATA
    future<void> r1 = async(launch::async, &DataHandler::FilterData, ref(d1), ref(filter));
    r1.get();
    
    //PRITNING POSITION
    promise<int> pr;
    future<int> ft = pr.get_future();
    future<void> result = async(launch::async,&DataHandler::FindNthValue,&d1,ref(ft));
    int N {0};
    cout<<"Enter the position : ";
    cin>>N;
    pr.set_value(N); 
    result.get();

    //PRINTING ODD SUM
    try
    {
        future<void> r2 = async(launch::async, &DataHandler::SumOfOdd, &d1);
        r2.get();
    }
    catch(NoOddNumbers& e)
    {
        cout << e.what() << '\n';
    }
    
    //PERFORMING OVERLOADING
    cout<<"The sum of all elements of d1 & d2 are : " << d1+d2<<endl;

    
}