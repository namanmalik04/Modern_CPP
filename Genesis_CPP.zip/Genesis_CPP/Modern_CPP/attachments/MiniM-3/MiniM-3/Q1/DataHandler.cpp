#include "DataHandler.h"
#include"NoOddNumbers.h"
std::ostream &operator<<(std::ostream &os, const DataHandler &rhs)
{
    os << "_data: " << rhs._data;
    return os;
}

DataHandler::DataHandler(int data[])
{
    for (int i = 0; i < 5; i++)
        _data[i] = data[i];
}

void DataHandler::FilterData(const function<bool(int)>& filter)
{
    for (int i = 0; i < 5; i++)
    {
        if (filter(_data[i]))
            cout << _data[i] << " ";
    }
    cout << endl;
}

void DataHandler::FindNthValue(future<int> &ft)
{
    int N = ft.get();
    if (N >= 0 && N < 5)
        cout << "The element at the Nth Position is : " << _data[N] << endl;
    else
        cout << "Position is out of bound" << endl;
}
void DataHandler::SumOfOdd()
{
    int sum = 0;
    for (int i = 0; i < 5; i++)
    {

        if (_data[i] % 2 != 0)
            sum += _data[i];
    }
    if (sum != 0)
        cout << "The sum of all odd numbers are : " << sum << endl;
    else
        throw NoOddNumbers("No odd numbers found");
}

int DataHandler ::operator+(DataHandler &obj)
{
    int sum = 0;
    for (int i = 0; i < 5; i++)
    {
        sum += this->_data[i] + obj._data[i];
    }
    return sum;
}