#ifndef IDNOTFOUND_H
#define IDNOTFOUND_H

#include <stdexcept>
#include <cstring>
#include <iostream>


class IDNotFound
{
private:

    char* _msg;
    
public:
    IDNotFound()= delete;
    explicit IDNotFound(const char* msg) {
        _msg = new char[strlen(msg) + 1];
        strcpy(_msg,msg);
    }
    IDNotFound(const IDNotFound&) = default;
    IDNotFound(IDNotFound&&) = default;
    IDNotFound& operator=(const IDNotFound&) = delete;
    IDNotFound& operator=(IDNotFound&&) = default;
    

    virtual const char * what() {return _msg;}
};





#endif // IDNOTFOUND_H
