#include <iostream>
#include "Functonalities.h"
#include "EmptyContainerException.h"
#include "EmptyInCreateObject.h"
#include "IDNotFound.h"


int FindHorsePower(CarContainer &carData, std::string carId)
{
    if(carData.empty()){
        throw EmptyContainerException("Data not found");
    }
    else{
        for(std::shared_ptr<Car> i : carData){
            if(i->carId() == carId){
                return i->getCarEngine().get().engineHorsePower();
            }
        }
    }



    throw IDNotFound("ID not found");
   

   
}

void CreateObjects(CarContainer &carData,EngineContainer &engineData){
    
    engineData.push_back(
        Engine("rjrk5",EngineType::HYBRID,1234,5567)
    );

    carData.emplace_back(
        std::make_shared<Car>("y584","maruti",CarType::HATCHBACK,
        engineData[0]
        ,101.3)
    );





}


