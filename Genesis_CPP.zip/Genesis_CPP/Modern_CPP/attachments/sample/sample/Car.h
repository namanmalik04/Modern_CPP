#ifndef CAR_H
#define CAR_H

#include <iostream>
#include <functional>
#include <memory>
#include "CarType.h"
#include "Engine.h"

class Car
{
private:
    const std::string _carId {""};
    const std::string _carBrand {""};
    const CarType _carType {CarType :: SEDAN};
    //std::shared_ptr<Engine>_carEngine;
    std::reference_wrapper<Engine>_carEngine;
    float _carPrice {0.0f};

    
public:
 
    Car(const std::string,const std::string , const CarType,std::reference_wrapper<Engine>carEngine, float carPrice);


    std::string carId() const { return _carId; }

    std::string carBrand() const { return _carBrand; }

    CarType carType() const { return _carType; }

    std::reference_wrapper<Engine>getCarEngine() const { return _carEngine; }

    float getCarPrice() const { return _carPrice; }
    void setCarPrice(float carPrice_) { _carPrice = carPrice_; }

    Car()= delete;
    Car(const Car&) = delete;
    Car(Car&&) = delete;
    Car operator=(const Car&) = delete;
    Car operator=(Car&&) = delete;
    ~Car() = default;

    friend std::ostream &operator<<(std::ostream &os, const Car &rhs);


};


#endif // CAR_H



