
#include <iostream>
#include "Car.h"


std::ostream &operator<<(std::ostream &os, const Car &rhs) {
    os << "_carId: " << rhs._carId
       << " _carBrand: " << rhs._carBrand
       << " _carType: " << static_cast<int>(rhs._carType)
       << " carEngine: " << rhs._carEngine.get()
       << " _carPrice: " << rhs._carPrice;
    return os;
}

Car::Car(const std::string carId,const std::string carBrand, const CarType carType,std::reference_wrapper<Engine>carEngine, float carPrice) :
_carId(carId), _carBrand(carBrand), _carType(carType),_carEngine(carEngine), _carPrice(carPrice) {}
