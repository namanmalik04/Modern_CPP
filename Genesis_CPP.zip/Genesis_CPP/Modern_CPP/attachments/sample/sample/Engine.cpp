
#include "Engine.h"

Engine :: Engine (const std::string engineNumber,EngineType engineType, int engineHorsePower, int engineTorque) :
_engineNumber(engineNumber), _engineType(engineType), _engineHorsePower(engineHorsePower), _engineTorque(engineTorque) {}
std::ostream &operator<<(std::ostream &os, const Engine &rhs) {
    os << "_engineNumber: " << rhs._engineNumber
       << " _engineType: " << static_cast<int>(rhs._engineType)
       << " _engineHorsePower: " << rhs._engineHorsePower
       << " _engineTorque: " << rhs._engineTorque;
    return os;
}

