#ifndef CARTYPE_H
#define CARTYPE_H

enum class CarType{
    SEDAN,
    SUV,
    HATCHBACK,
    SPORTS
};

#endif // CARTYPE_H
