#ifndef FUNCTONALITIES_H
#define FUNCTONALITIES_H

#include "Car.h"
#include <memory>
#include <vector>
#include "Engine.h"
#include "Car.h"
#include <functional>

using CarPointer = std::shared_ptr<Car>;
using CarContainer = std::vector<CarPointer>;
using EngineContainer = std::vector<Engine>;

//using EngineRefrence = std::reference_wrapper<Engine>;

void CreateObjects(CarContainer &carData,EngineContainer &engineData);

int FindHorsePower(CarContainer& data,std::string carId);


#endif // FUNCTONALITIES_H
