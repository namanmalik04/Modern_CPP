#ifndef EMPTYINCREATEOBJECT_H
#define EMPTYINCREATEOBJECT_H


#include <stdexcept>
#include <cstring>



class EmptyInCreateObject
{
private:

    char* _msg;
    
public:
    EmptyInCreateObject()= delete;
    explicit EmptyInCreateObject(const char* msg) {
        _msg = new char[strlen(msg) + 1];
        strcpy(_msg,msg);
    }
    EmptyInCreateObject(const EmptyInCreateObject&) = default;
    EmptyInCreateObject(EmptyInCreateObject&&) = default;
    EmptyInCreateObject& operator=(const EmptyInCreateObject&) = delete;
    EmptyInCreateObject& operator=(EmptyInCreateObject&&) = default;
    ~EmptyInCreateObject() = default;
    

    virtual const char * what() {return _msg;}
};




#endif // EMPTYINCREATEOBJECT_H
