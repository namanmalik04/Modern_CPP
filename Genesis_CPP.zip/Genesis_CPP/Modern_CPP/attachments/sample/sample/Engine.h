#ifndef ENGINE_H
#define ENGINE_H

#include <iostream>
#include "EngineType.h"

class Engine
{
private:
    const std::string _engineNumber;
    EngineType _engineType;
    int _engineHorsePower;
    int _engineTorque;
public:

    Engine (const std::string engineNumber,EngineType engineType, int engineHorsePower, int engineTorque);

    
    Engine()= default;
    Engine(const Engine&) = delete;
    Engine(Engine&&) = default;
    Engine& operator=(const Engine&) = delete;
    Engine& operator=(Engine&&) = default;
    ~Engine() = default;

    std::string engineNumber() const { return _engineNumber; }

    EngineType engineType() const { return _engineType; }
    void setEngineType(const EngineType &engineType) { _engineType = engineType; }

    int engineHorsePower() const { return _engineHorsePower; }
    void setEngineHorsePower(int engineHorsePower) { _engineHorsePower = engineHorsePower; }

    int engineTorque() const { return _engineTorque; }
    void setEngineTorque(int engineTorque) { _engineTorque = engineTorque; }

    friend std::ostream &operator<<(std::ostream &os, const Engine &rhs);
};




#endif // ENGINE_H
