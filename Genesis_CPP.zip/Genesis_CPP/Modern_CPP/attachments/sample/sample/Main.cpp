#include <iostream>
#include "Functonalities.h"
#include "EmptyContainerException.h"
#include "IDNotFound.h"
#include "EmptyInCreateObject.h"


using namespace std;

class Main
{
private:
    int v;
public:
    Main(/* args */);
    ~Main();

    int getV() const { return v; }
    void setV(int v_) { v = v_; }
};



int main(){

   
    CarContainer Cardata;
    EngineContainer engineData;

  try{
    CreateObjects(Cardata,engineData);
  }
  catch(EmptyContainerException &e){
    cout << e.what();
  }

   

    try{
        cout << FindHorsePower(Cardata,"yth");
    }
    catch(EmptyContainerException &e){
        cout << e.what();
    }
    catch(IDNotFound &e){
        cout << e.what();
    }
    

    return 0;
}