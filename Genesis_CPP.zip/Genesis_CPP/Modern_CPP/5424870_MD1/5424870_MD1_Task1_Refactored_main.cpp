#include "5424870_MD1_Task1_Refactored_Car.h"
#include "5424870_MD1_Task1_Refactored_Truck.h"
#include "5424870_MD1_Task1_Refactored_ElectricCar.h"

int main() {
    Car car("CAR1234", 2020, 4);
    Truck truck("TRK5678", 2018, 3.5);
    ElectricCar ecar("ELE9012", 2022, 92.5);

    Vehicle* vehicles[] = { &car, &truck, &ecar };

    for (auto* v : vehicles) {
        v->displayInfo();
        v->runDiagnostics();
        std::cout << "-----------------------------" << std::endl;
    }

    return 0;
}
