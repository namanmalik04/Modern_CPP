#include "5424870_MD1_Task1_Refactored_ElectricCar.h"

ElectricCar::ElectricCar(const std::string& vin, int year, double batteryHealth)
    : Vehicle(vin, year), m_batteryHealth(batteryHealth) {}

void ElectricCar::runDiagnostics() const {
    std::cout << "Running electric car diagnostics (Battery Health: "
              << m_batteryHealth << "%)" << std::endl;
}
