#include "5424870_MD1_Task1_Truck.h"

Truck::Truck(const std::string& vin, int year, double payloadCapacity)
    : Vehicle(vin, year), m_payloadCapacity(payloadCapacity) {}

void Truck::runDiagnostics() {
    std::cout << "Running truck diagnostics" << std::endl;
}
