#include "5424870_MD1_Task1_Refactored_Truck.h"

Truck::Truck(const std::string& vin, int year, double payloadCapacity)
    : Vehicle(vin, year), m_payloadCapacity(payloadCapacity) {}

void Truck::runDiagnostics() const {
    std::cout << "Running truck diagnostics (Payload: " 
              << m_payloadCapacity << " tons)" << std::endl;
}
