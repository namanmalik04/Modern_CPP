#include "5424870_MD1_Task2_Refactored_ECU.h"

ECU::ECU(SensorType sensorType)
    : m_sensor(sensorType), m_actuator(nullptr) {}

void ECU::connectActuator(Actuator* act) {
    m_actuator = act;
}

void ECU::showStatus() const {
    std::cout << "=== ECU STATUS ===" << std::endl;
    m_sensor.showSensor();

    if (m_actuator) {
        m_actuator->showActuator();
    } else {
        std::cout << "No actuator connected." << std::endl;
    }
    std::cout << "==================" << std::endl;
}
