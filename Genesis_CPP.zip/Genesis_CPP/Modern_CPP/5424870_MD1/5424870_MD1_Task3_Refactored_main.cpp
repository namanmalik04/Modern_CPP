#include "5424870_MD1_Task3_Refactored_Vehicle.h"

int main() {
    Vehicle v1;                    // Default constructor
    Vehicle v2("Sedan", 2022);     // Custom constructor
    Vehicle v3("SUV", 2023);       // Custom constructor

    VehicleArray vehicles = { &v1, &v2, &v3 };

    for (auto* vehicle : vehicles) {
        vehicle->show();
    }

    return 0;
}
