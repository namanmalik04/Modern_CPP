#include "5424870_MD1_Task2_ECU.h"

int main() {
    ECU ecu(SensorType::TEMPERATURE);

    ecu.showStatus();

    Actuator motor(ActuatorType::MOTOR);
    ecu.connectActuator(&motor);

    ecu.showStatus();

    return 0;
}
