#include "5424870_MD1_Task2_Refactored_Sensor.h"

Sensor::Sensor(SensorType type) : m_type(type) {}

void Sensor::showSensor() const {
    std::cout << "Sensor Type: ";
    switch (m_type) {
        case SensorType::TEMPERATURE:
            std::cout << "Temperature";
            break;
        case SensorType::PRESSURE:
            std::cout << "Pressure";
            break;
        case SensorType::SPEED:
            std::cout << "Speed";
            break;
    }
    std::cout << std::endl;
}
