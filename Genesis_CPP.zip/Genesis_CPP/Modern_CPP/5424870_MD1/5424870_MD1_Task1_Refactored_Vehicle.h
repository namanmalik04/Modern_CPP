#ifndef VEHICLE_H
#define VEHICLE_H

#include <iostream>
#include <string>

class Vehicle {
protected:
    std::string m_vin;
    int m_year;

public:
    Vehicle(const std::string& vin, int year);
    virtual void runDiagnostics() const;
    void displayInfo() const;
    virtual ~Vehicle() = default;
};

#endif
