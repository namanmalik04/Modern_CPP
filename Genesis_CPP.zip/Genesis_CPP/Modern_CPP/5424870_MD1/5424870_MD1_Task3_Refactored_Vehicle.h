#ifndef VEHICLE_H
#define VEHICLE_H

#include <iostream>
#include <string>

class Vehicle {
private:
    std::string m_model;
    int m_year;

public:
    Vehicle(const std::string& model, int year);
    Vehicle();
    void show() const;
};

using VehicleArray = Vehicle*[];

#endif
