#ifndef ECU_H
#define ECU_H

#include "5424870_MD1_Task2_Refactored_Sensor.h"
#include "5424870_MD1_Task2_Refactored_Actuator.h"

class ECU {
private:
    Sensor m_sensor;           // Composition
    Actuator* m_actuator;      // Aggregation

public:
    explicit ECU(SensorType sensorType);
    void connectActuator(Actuator* act);
    void showStatus() const;
};

#endif
