#include "5424870_MD1_Task1_Refactored_Vehicle.h"

Vehicle::Vehicle(const std::string& vin, int year)
    : m_vin(vin), m_year(year) {}

void Vehicle::runDiagnostics() const {
    std::cout << "Running generic diagnostics" << std::endl;
}

void Vehicle::displayInfo() const {
    std::cout << "VIN: " << m_vin << " | Year: " << m_year << std::endl;
}
