#ifndef ACTUATOR_H
#define ACTUATOR_H

#include <iostream>

enum class ActuatorType {
    MOTOR,
    VALVE,
    DISPLAY
};

class Actuator {
private:
    ActuatorType m_type;

public:
    Actuator(ActuatorType type);
    void showActuator();
};

#endif
