#ifndef CAR_H
#define CAR_H

#include "5424870_MD1_Task1_Vehicle.h"

class Car : public Vehicle {
private:
    int m_numDoors;

public:
    Car(const std::string& vin, int year, int numDoors);
    void runDiagnostics() override;
};

#endif
