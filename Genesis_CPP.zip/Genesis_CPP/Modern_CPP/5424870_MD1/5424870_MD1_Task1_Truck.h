#ifndef TRUCK_H
#define TRUCK_H

#include "5424870_MD1_Task1_Vehicle.h"

class Truck : public Vehicle {
private:
    double m_payloadCapacity;

public:
    Truck(const std::string& vin, int year, double payloadCapacity);
    void runDiagnostics() override;
};

#endif
