#include "5424870_MD1_Task2_Actuator.h"

Actuator::Actuator(ActuatorType type) : m_type(type) {}

void Actuator::showActuator() {
    std::cout << "Actuator Type: ";
    switch (m_type) {
        case ActuatorType::MOTOR:
            std::cout << "Motor";
            break;
        case ActuatorType::VALVE:
            std::cout << "Valve";
            break;
        case ActuatorType::DISPLAY:
            std::cout << "Display";
            break;
    }
    std::cout << std::endl;
}
