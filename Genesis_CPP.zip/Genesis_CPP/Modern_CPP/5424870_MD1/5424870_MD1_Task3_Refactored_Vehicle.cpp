#include "5424870_MD1_Task3_Refactored_Vehicle.h"

Vehicle::Vehicle(const std::string& model, int year)
    : m_model(model), m_year(year) {}

Vehicle::Vehicle()
    : Vehicle("Generic", 2020) {}

void Vehicle::show() const {
    std::cout << "Model: " << m_model << " | Year: " << m_year << std::endl;
}
