#ifndef ECU_H
#define ECU_H

#include "5424870_MD1_Task2_Sensor.h"
#include "5424870_MD1_Task2_Actuator.h"

class ECU {
private:
    Sensor m_sensor;
    Actuator* m_actuator;

public:
    ECU(SensorType sensorType);
    void connectActuator(Actuator* act);
    void showStatus();
};

#endif
