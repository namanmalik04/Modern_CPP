#include "5424870_MD1_Task3_Vehicle.h"

Vehicle::Vehicle(std::string model, int year)
    : m_model(model), m_year(year) {}

Vehicle::Vehicle()
    : Vehicle("Generic", 2020) {}

void Vehicle::show() {
    std::cout << "Model: " << m_model << ", Year: " << m_year << std::endl;
}
