#ifndef SENSOR_H
#define SENSOR_H

#include <iostream>

enum class SensorType {
    TEMPERATURE,
    PRESSURE,
    SPEED
};

class Sensor {
private:
    SensorType m_type;

public:
    explicit Sensor(SensorType type);
    void showSensor() const;
};

#endif
