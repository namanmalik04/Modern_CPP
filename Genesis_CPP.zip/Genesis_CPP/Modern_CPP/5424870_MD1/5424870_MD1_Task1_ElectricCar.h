#ifndef ELECTRICCAR_H
#define ELECTRICCAR_H

#include "5424870_MD1_Task1_Vehicle.h"

class ElectricCar : public Vehicle {
private:
    double m_batteryHealth;

public:
    ElectricCar(const std::string& vin, int year, double batteryHealth);
    void runDiagnostics() final;
};

#endif
