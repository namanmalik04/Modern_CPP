#include "5424870_MD1_Task1_Vehicle.h"

Vehicle::Vehicle(const std::string& vin, int year)
    : m_vin(vin), m_year(year) {}

void Vehicle::runDiagnostics() {
    std::cout << "Running generic diagnostics" << std::endl;
}

void Vehicle::displayInfo() {
    std::cout << "VIN: " << m_vin << ", Year: " << m_year << std::endl;
}
