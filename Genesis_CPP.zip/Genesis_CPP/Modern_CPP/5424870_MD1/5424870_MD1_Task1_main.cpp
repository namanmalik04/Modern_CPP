#include "5424870_MD1_Task1_Car.h"
#include "5424870_MD1_Task1_Truck.h"
#include "5424870_MD1_Task1_ElectricCar.h"

int main() {
    Car car("CAR1234", 2020, 4);
    Truck truck("TRK5678", 2018, 3.5);
    ElectricCar ecar("ELE9012", 2022, 92.5);

    Vehicle* vehicles[3] = { &car, &truck, &ecar };

    for (int i = 0; i < 3; ++i) {
        vehicles[i]->displayInfo();
        vehicles[i]->runDiagnostics();
        std::cout << std::endl;
    }

    return 0;
}
