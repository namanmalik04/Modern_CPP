#include "5424870_MD1_Task2_ECU.h"

ECU::ECU(SensorType sensorType)
    : m_sensor(sensorType), m_actuator(nullptr) {}

void ECU::connectActuator(Actuator* act) {
    m_actuator = act;
}

void ECU::showStatus() {
    std::cout << "ECU Status:" << std::endl;
    m_sensor.showSensor();

    if (m_actuator != nullptr) {
        m_actuator->showActuator();
    } else {
        std::cout << "No actuator connected" << std::endl;
    }
}
