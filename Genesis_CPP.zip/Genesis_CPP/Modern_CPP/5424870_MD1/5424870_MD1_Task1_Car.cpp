#include "5424870_MD1_Task1_Car.h"

Car::Car(const std::string& vin, int year, int numDoors)
    : Vehicle(vin, year), m_numDoors(numDoors) {}

void Car::runDiagnostics() {
    std::cout << "Running car diagnostics" << std::endl;
}
