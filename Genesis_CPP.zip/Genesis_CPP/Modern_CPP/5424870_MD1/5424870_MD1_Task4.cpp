#include <iostream>
#include <string>
using namespace std;

// Base class: SafetyFeature
class SafetyFeature {
protected:
    string featureName;
    bool isEnabled;

public:
    // Defaulted constructor
    SafetyFeature() = default;

    // Parameterized constructor
    SafetyFeature(const string& name, bool enabled)
        : featureName(name), isEnabled(enabled) {}

    // Deleted copy constructor
    SafetyFeature(const SafetyFeature&) = delete;

    // Virtual function
    virtual void activate() {
        cout << "Activating generic safety feature" << endl;
    }

    // Virtual destructor (for safety)
    virtual ~SafetyFeature() = default;
};

// Derived class: Airbag
class Airbag : public SafetyFeature {
    int deploymentThreshold;

public:
    Airbag(const string& name, bool enabled, int threshold)
        : SafetyFeature(name, enabled), deploymentThreshold(threshold) {}

    void activate() override {
        cout << "Activating airbag" << endl;
    }
};

// Derived class: ABS (final activation method)
class ABS : public SafetyFeature {
    double wheelSpeedSensorAccuracy;

public:
    ABS(const string& name, bool enabled, double accuracy)
        : SafetyFeature(name, enabled), wheelSpeedSensorAccuracy(accuracy) {}

    void activate() final override {
        cout << "Activating ABS" << endl;
    }
};

// Main function
int main() {
    // Create Airbag instance
    Airbag airbag("Front Airbag", true, 30);
    airbag.activate();

    // Create ABS instance
    ABS abs("Anti-lock Braking", true, 98.5);
    abs.activate();

    // Uncomment below line to demonstrate copy failure
    // Airbag copyAirbag = airbag;  // ❌ Error: copy constructor is deleted

    return 0;
}
