#include "5424870_MD1_Task1_Refactored_Car.h"

Car::Car(const std::string& vin, int year, int numDoors)
    : Vehicle(vin, year), m_numDoors(numDoors) {}

void Car::runDiagnostics() const {
    std::cout << "Running car diagnostics (Doors: " << m_numDoors << ")" << std::endl;
}
