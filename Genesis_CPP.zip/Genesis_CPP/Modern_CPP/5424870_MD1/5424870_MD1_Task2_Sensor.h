#ifndef SENSOR_H
#define SENSOR_H

#include <iostream>
#include <string>

enum class SensorType {
    TEMPERATURE,
    PRESSURE,
    SPEED
};

class Sensor {
private:
    SensorType m_type;

public:
    Sensor(SensorType type);
    void showSensor();
};

#endif
