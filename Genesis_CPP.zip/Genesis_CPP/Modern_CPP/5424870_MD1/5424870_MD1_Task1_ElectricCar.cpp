#include "5424870_MD1_Task1_ElectricCar.h"

ElectricCar::ElectricCar(const std::string& vin, int year, double batteryHealth)
    : Vehicle(vin, year), m_batteryHealth(batteryHealth) {}

void ElectricCar::runDiagnostics() {
    std::cout << "Running electric car diagnostics" << std::endl;
}
