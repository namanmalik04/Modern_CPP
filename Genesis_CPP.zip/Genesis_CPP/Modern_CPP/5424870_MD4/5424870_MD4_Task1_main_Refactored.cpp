#include <iostream>
#include <vector>
#include <algorithm>
#include <utility>
#include "5424870_MD4_Task1_Vehicle_Refactored.h"

// Logging functions
inline void logVehicleByValue(Vehicle v) {
    std::cout << "[By Value] ";
    v.print();
}

inline void logVehicleByRef(Vehicle& v) {
    std::cout << "[By Ref] ";
    v.print();
}

inline void logVehicleByRRef(Vehicle&& v) {
    std::cout << "[By Rvalue Ref] ";
    v.print();
}

inline void logVehicleByPtr(Vehicle* v) {
    std::cout << "[By Pointer] ";
    if (v) v->print();
}

int main() {
    // Step 1: Create vehicle objects in a vector
    std::vector<Vehicle> vehicles{
        {101, "Sedan", 85.0, 12.5, Status::OK},
        {102, "SUV", 95.0, 11.8, Status::WARN},
        {103, "Coupe", 105.0, 12.0, Status::FAIL}
    };

    // Step 2: Update data
    vehicles[0].updateTemperature(88.5);
    vehicles[1].updateVoltage(11.5);

    // Step 3: Set status using rvalue reference
    vehicles[0].setStatus(Status::WARN);

    // Step 4: Log using different parameter styles
    logVehicleByValue(vehicles[0]);
    logVehicleByRef(vehicles[1]);
    logVehicleByRRef(std::move(vehicles[2]));
    logVehicleByPtr(&vehicles[0]);

    // Step 5: Filter using lambda and copy_if
    std::vector<Vehicle> filteredVehicles;
    filteredVehicles.reserve(vehicles.size());

    auto filterCondition = [](const Vehicle& v) {
        return v.getTemperature() > 90.0 || v.getVoltage() < 12.0;
    };

    std::copy_if(vehicles.begin(), vehicles.end(), std::back_inserter(filteredVehicles), filterCondition);

    // Step 6: Display filtered results
    std::cout << "\nFiltered Vehicles (Temp > 90°C or Volt < 12V):\n";
    for (const auto& vehicle : filteredVehicles) {
        vehicle.print();
    }

    return 0;
}
