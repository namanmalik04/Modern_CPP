#ifndef INVENTORY_H
#define INVENTORY_H

#include <iostream>
#include <string>
#include <stdexcept>
using namespace std;

class Inventory {
private:
    string description_of_product;
    int balance_stock;
    int productcode;

public:
    // Default constructor
    Inventory();

    // Parameterized constructor
    Inventory(const string& desc, int stock, int code);

    // Member functions
    void purchase(int quantity);
    void sale(int quantity);
    void display() const;

    // Getter for product code
    int getProductCode() const;
};

// Global search function
void Search(Inventory arr[], int size, int code);

#endif
