#include "5424870_MD4_Task3_SignalBuffer.h"
#include <iostream>
#include <utility>

// Default constructor
SignalBuffer::SignalBuffer() noexcept
    : m_id(-1), m_source(), m_strength(-999.0f), m_timestamp(0), m_status(Status::LOST) {}

// Member-list constructor
SignalBuffer::SignalBuffer(int id, const std::string& source, float strength,
                           std::uint64_t timestamp, Status status) noexcept
    : m_id(id), m_source(source), m_strength(strength), m_timestamp(timestamp), m_status(status) {}

// Move constructor
SignalBuffer::SignalBuffer(SignalBuffer&& other) noexcept
    : m_id(other.m_id),
      m_source(std::move(other.m_source)),
      m_strength(other.m_strength),
      m_timestamp(other.m_timestamp),
      m_status(other.m_status)
{
    // Put other into a valid moved-from state
    other.m_id = -1;
    other.m_source.clear();
    other.m_strength = -999.0f;
    other.m_timestamp = 0;
    other.m_status = Status::LOST;
}

// Move assignment
SignalBuffer& SignalBuffer::operator=(SignalBuffer&& other) noexcept {
    if (this != &other) {
        m_id = other.m_id;
        m_source = std::move(other.m_source);
        m_strength = other.m_strength;
        m_timestamp = other.m_timestamp;
        m_status = other.m_status;

        // leave other in valid moved-from state
        other.m_id = -1;
        other.m_source.clear();
        other.m_strength = -999.0f;
        other.m_timestamp = 0;
        other.m_status = Status::LOST;
    }
    return *this;
}

// Update strength
void SignalBuffer::updateStrength(float s) noexcept {
    m_strength = s;
}

// rvalue-only setStatus
void SignalBuffer::setStatus(Status&& s) noexcept {
    m_status = std::move(s);
}

// Accessors
float SignalBuffer::getStrength() const noexcept { return m_strength; }
Status SignalBuffer::getStatus() const noexcept { return m_status; }
int SignalBuffer::getId() const noexcept { return m_id; }
const std::string& SignalBuffer::getSource() const noexcept { return m_source; }
std::uint64_t SignalBuffer::getTimestamp() const noexcept { return m_timestamp; }

// Print
void SignalBuffer::print() const noexcept {
    const char* statusNames[] = { "VALID", "WEAK", "LOST" };
    std::cout << "Buffer ID: " << m_id
              << ", Source: " << (m_source.empty() ? "<moved-from>" : m_source)
              << ", Strength: " << m_strength << " dBm"
              << ", Timestamp: " << m_timestamp
              << ", Status: " << statusNames[static_cast<int>(m_status)]
              << '\n';
}
