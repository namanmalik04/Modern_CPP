#include <iostream>
#include <vector>
#include <algorithm>
#include <utility>
#include "5424870_MD4_Task2_Sensor_Refactored.h"

// Logging helpers
inline void logSensorByRef(Sensor& sensor) {
    std::cout << "[By Ref] ";
    sensor.print();
}

inline void logSensorByRRef(Sensor&& sensor) {
    std::cout << "[By Rvalue Ref] ";
    sensor.print();
}

inline void logSensorByPtr(Sensor* sensor) {
    std::cout << "[By Pointer] ";
    if (sensor) sensor->print();
}

int main() {
    // Step 1: Create sensors in a vector
    std::vector<Sensor> sensors{
        {201, "Temperature", 1.05f, 0.2f, State::CALIBRATED},
        {202, "Pressure", 0.98f, -0.1f, State::UNCALIBRATED},
        {203, "Humidity", 1.00f, 0.0f, State::ERROR}
    };

    // Step 2: Apply calibration
    sensors[0].applyCalibration(1.10f, 0.25f);
    sensors[1].applyCalibration(1.00f, 0.05f);

    // Step 3: Set state using rvalue reference
    sensors[1].setState(State::CALIBRATED);

    // Step 4: Log sensors
    logSensorByRef(sensors[0]);
    logSensorByRRef(std::move(sensors[1]));
    logSensorByPtr(&sensors[2]);

    // Step 5: Lambda to check if sensor is "critical"
    auto isCritical = [](const Sensor& s) noexcept {
        return s.getGain() > 1.0f || s.getState() == State::ERROR;
    };

    // Step 6: Filter sensors using STL
    std::vector<Sensor> criticalSensors;
    std::copy_if(sensors.begin(), sensors.end(),
                 std::back_inserter(criticalSensors), isCritical);

    // Step 7: Display critical sensors
    std::cout << "\nCritical Sensors (Gain > 1.0 or State == ERROR):\n";
    for (const auto& sensor : criticalSensors) {
        sensor.print();
    }

    return 0;
}
