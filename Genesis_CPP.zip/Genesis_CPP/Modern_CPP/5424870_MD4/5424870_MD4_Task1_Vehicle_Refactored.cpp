#include "5424870_MD4_Task1_Vehicle_Refactored.h"

// Constructor definition
Vehicle::Vehicle(int id, const std::string& model, double temperature, double voltage, Status status)
    : m_id(id), m_model(model), m_temperature(temperature),
      m_voltage(voltage), m_status(status) {}

// Update engine temperature
void Vehicle::updateTemperature(double newTemperature) {
    m_temperature = newTemperature;
}

// Update battery voltage
void Vehicle::updateVoltage(double newVoltage) {
    m_voltage = newVoltage;
}

// Set status using rvalue reference
void Vehicle::setStatus(Status&& newStatus) {
    m_status = std::move(newStatus);
}

// Return temperature
double Vehicle::getTemperature() const noexcept {
    return m_temperature;
}

// Return voltage
double Vehicle::getVoltage() const noexcept {
    return m_voltage;
}

// Print vehicle details
void Vehicle::print() const {
    static const char* statusText[] = { "OK", "WARN", "FAIL" };

    std::cout << "Vehicle ID: " << m_id
              << ", Model: " << m_model
              << ", Temp: " << m_temperature << "°C"
              << ", Voltage: " << m_voltage << "V"
              << ", Status: " << statusText[static_cast<int>(m_status)]
              << '\n';
}
