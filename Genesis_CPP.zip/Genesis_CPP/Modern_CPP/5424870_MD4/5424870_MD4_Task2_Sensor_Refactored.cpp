#include "5424870_MD4_Task2_Sensor_Refactored.h"

// Constructor
Sensor::Sensor(int id, const std::string& type, float gain, float offset, State state) noexcept
    : m_id(id), m_type(type), m_gain(gain), m_offset(offset), m_state(state) {}

// Apply calibration
void Sensor::applyCalibration(float newGain, float newOffset) noexcept {
    m_gain = newGain;
    m_offset = newOffset;
}

// Set state using rvalue reference
void Sensor::setState(State&& newState) noexcept {
    m_state = std::move(newState);
}

// Accessors
float Sensor::getGain() const noexcept {
    return m_gain;
}

State Sensor::getState() const noexcept {
    return m_state;
}

// Print sensor information
void Sensor::print() const noexcept {
    static const char* stateNames[] = {"UNCALIBRATED", "CALIBRATED", "ERROR"};

    std::cout << "Sensor ID: " << m_id
              << ", Type: " << m_type
              << ", Gain: " << m_gain
              << ", Offset: " << m_offset
              << ", State: " << stateNames[static_cast<int>(m_state)]
              << '\n';
}
