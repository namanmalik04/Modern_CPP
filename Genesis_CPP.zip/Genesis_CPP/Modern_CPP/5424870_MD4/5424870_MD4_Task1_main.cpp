#include <iostream>
#include "5424870_MD4_Task1_Vehicle.h"

// Demonstrates call by value
void logVehicleByValue(Vehicle v) {
    std::cout << "[By Value] ";
    v.print();
}

// Demonstrates call by reference
void logVehicleByRef(Vehicle& v) {
    std::cout << "[By Ref] ";
    v.print();
}

// Demonstrates call by rvalue reference
void logVehicleByRRef(Vehicle&& v) {
    std::cout << "[By Rvalue Ref] ";
    v.print();
}

// Demonstrates call by pointer
void logVehicleByPtr(Vehicle* v) {
    std::cout << "[By Pointer] ";
    if (v) v->print();
}

int main() {
    // Step 1: Create vehicle objects
    Vehicle vehicles[3] = {
        Vehicle(101, "Sedan", 85.0, 12.5, Status::OK),
        Vehicle(102, "SUV", 95.0, 11.8, Status::WARN),
        Vehicle(103, "Coupe", 105.0, 12.0, Status::FAIL)
    };

    // Step 2: Update temperature and voltage
    vehicles[0].updateTemperature(88.5);
    vehicles[1].updateVoltage(11.5);

    // Step 3: Set status using rvalue reference
    vehicles[0].setStatus(Status::WARN);

    // Step 4: Log vehicles with different parameter passing
    logVehicleByValue(vehicles[0]);
    logVehicleByRef(vehicles[1]);
    logVehicleByRRef(std::move(vehicles[2]));
    logVehicleByPtr(&vehicles[0]);

    // Step 5: Filter vehicles based on condition
    Vehicle filtered[3];
    int filteredCount = 0;

    auto filter = [](const Vehicle& v) {
        return v.getTemperature() > 90.0 || v.getVoltage() < 12.0;
    };

    for (int i = 0; i < 3; ++i) {
        if (filter(vehicles[i])) {
            filtered[filteredCount++] = vehicles[i];
        }
    }

    // Step 6: Print filtered results
    std::cout << "\nFiltered Vehicles (Temp > 90°C or Volt < 12V):\n";
    for (int i = 0; i < filteredCount; ++i) {
        filtered[i].print();
    }

    return 0;
}
