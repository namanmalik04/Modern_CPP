#ifndef SENSOR_REFACTORED_H
#define SENSOR_REFACTORED_H

#include <string>
#include <iostream>
#include <utility>

// Enumeration for sensor calibration state
enum class State { UNCALIBRATED, CALIBRATED, ERROR };

class Sensor {
private:
    int m_id{};
    std::string m_type{};
    float m_gain{};
    float m_offset{};
    State m_state{State::UNCALIBRATED};

public:
    // Constructor using const references and uniform initialization
    Sensor(int id, const std::string& type, float gain, float offset, State state) noexcept;

    // Deleted copy constructor
    Sensor(const Sensor&) = delete;

    // Calibration update
    void applyCalibration(float newGain, float newOffset) noexcept;

    // Set state using rvalue reference
    void setState(State&& newState) noexcept;
    void setState(const State&) = delete;

    // Accessors
    [[nodiscard]] float getGain() const noexcept;
    [[nodiscard]] State getState() const noexcept;

    // Display sensor details
    void print() const noexcept;
};

#endif
