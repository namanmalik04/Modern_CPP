#ifndef SIGNALBUFFER_H
#define SIGNALBUFFER_H

#include <string>
#include <cstdint>

enum class Status { VALID, WEAK, LOST };

class SignalBuffer {
private:
    int m_id;
    std::string m_source;
    float m_strength{ -999.0f }; // in-class initialization
    std::uint64_t m_timestamp;
    Status m_status;

public:
    // Constructors / Destructor
    SignalBuffer() noexcept; // default
    SignalBuffer(int id, const std::string& source, float strength,
                 std::uint64_t timestamp, Status status) noexcept;

    // Move-only: delete copy operations
    SignalBuffer(const SignalBuffer&) = delete;
    SignalBuffer& operator=(const SignalBuffer&) = delete;

    // Provide move operations
    SignalBuffer(SignalBuffer&& other) noexcept;
    SignalBuffer& operator=(SignalBuffer&& other) noexcept;

    ~SignalBuffer() noexcept = default;

    // Mutators
    void updateStrength(float s) noexcept;
    void setStatus(Status&& s) noexcept;
    void setStatus(const Status&) = delete; // enforce rvalue-only

    // Accessors
    float getStrength() const noexcept;
    Status getStatus() const noexcept;
    int getId() const noexcept;
    const std::string& getSource() const noexcept;
    std::uint64_t getTimestamp() const noexcept;

    // Utility
    void print() const noexcept;
};
#endif // SIGNALBUFFER_H
