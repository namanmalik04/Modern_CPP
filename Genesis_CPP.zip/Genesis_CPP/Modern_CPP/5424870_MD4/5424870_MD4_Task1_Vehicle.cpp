#include <iostream>
#include "5424870_MD4_Task1_Vehicle.h"

// Constructor using member initializer list
Vehicle::Vehicle(int id, std::string model, double temperature, double voltage, Status status)
    : m_id(id), m_model(model), m_temperature(temperature),
      m_voltage(voltage), m_status(status) {}

// Updates the engine temperature
void Vehicle::updateTemperature(double temperature) {
    m_temperature = temperature;
}

// Updates the battery voltage
void Vehicle::updateVoltage(double voltage) {
    m_voltage = voltage;
}

// Sets status using rvalue reference
void Vehicle::setStatus(Status&& status) {
    m_status = std::move(status);
}

// Returns engine temperature
double Vehicle::getTemperature() const {
    return m_temperature;
}

// Returns battery voltage
double Vehicle::getVoltage() const {
    return m_voltage;
}

// Displays vehicle information
void Vehicle::print() const {
    std::cout << "Vehicle ID: " << m_id
              << ", Model: " << m_model
              << ", Temp: " << m_temperature << "°C"
              << ", Voltage: " << m_voltage << "V"
              << ", Status: ";

    switch (m_status) {
        case Status::OK:
            std::cout << "OK";
            break;
        case Status::WARN:
            std::cout << "WARN";
            break;
        case Status::FAIL:
            std::cout << "FAIL";
            break;
    }
    std::cout << std::endl;
}
