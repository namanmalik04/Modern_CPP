#ifndef VEHICLE_H
#define VEHICLE_H

#include <string>

// Enumeration for vehicle diagnostic status
enum class Status { OK, WARN, FAIL };

class Vehicle {
private:
    int m_id;
    std::string m_model;
    double m_temperature;
    double m_voltage;
    Status m_status;

public:
    // Constructor
    Vehicle(int id, std::string model, double temperature, double voltage, Status status);

    // Mutators
    void updateTemperature(double temperature);
    void updateVoltage(double voltage);
    void setStatus(Status&& status);         // rvalue reference only
    void setStatus(const Status&) = delete;  // deleted lvalue overload

    // Accessors
    double getTemperature() const;
    double getVoltage() const;

    // Utility
    void print() const;
};

#endif
