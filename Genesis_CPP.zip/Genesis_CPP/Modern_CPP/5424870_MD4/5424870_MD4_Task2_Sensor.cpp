#include <iostream>
#include "5424870_MD4_Task2_Sensor.h"

// Constructor
Sensor::Sensor(int id, std::string type, float gain, float offset, State state)
    : m_id(id), m_type(type), m_gain(gain), m_offset(offset), m_state(state) {}

// Apply calibration
void Sensor::applyCalibration(float gain, float offset) {
    m_gain = gain;
    m_offset = offset;
}

// Set state using rvalue reference
void Sensor::setState(State&& state) {
    m_state = std::move(state);
}

// Get calibration gain
float Sensor::getGain() const {
    return m_gain;
}

// Get current state
State Sensor::getState() const {
    return m_state;
}

// Print sensor information
void Sensor::print() const {
    std::cout << "Sensor ID: " << m_id
              << ", Type: " << m_type
              << ", Gain: " << m_gain
              << ", Offset: " << m_offset
              << ", State: ";

    switch (m_state) {
        case State::UNCALIBRATED:
            std::cout << "UNCALIBRATED";
            break;
        case State::CALIBRATED:
            std::cout << "CALIBRATED";
            break;
        case State::ERROR:
            std::cout << "ERROR";
            break;
    }
    std::cout << std::endl;
}
