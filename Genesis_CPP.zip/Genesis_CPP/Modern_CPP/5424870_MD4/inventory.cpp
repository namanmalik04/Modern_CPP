#include "inventory.h"

// Default constructor
Inventory::Inventory() {
    description_of_product = "Unknown";
    balance_stock = 30; // greater than 20
    productcode = 0;
}

// Parameterized constructor
Inventory::Inventory(const string& desc, int stock, int code) {
    if (stock <= 20) {
        throw invalid_argument("Initial stock must be greater than 20");
    }
    description_of_product = desc;
    balance_stock = stock;
    productcode = code;
}

// Purchase function
void Inventory::purchase(int quantity) {
    balance_stock += quantity;
    cout << "After purchase stock: " << balance_stock << endl;
}

// Sale function
void Inventory::sale(int quantity) {
    balance_stock -= quantity;
    if (balance_stock < 20) {
        throw runtime_error("Low stock level");
    }
    cout << "After sale stock: " << balance_stock << endl;
}

// Display function
void Inventory::display() const {
    cout << "Product: " << description_of_product
         << ", Code: " << productcode
         << ", Stock: " << balance_stock << endl;
}

// Getter for product code
int Inventory::getProductCode() const {
    return productcode;
}

// Global Search function
void Search(Inventory arr[], int size, int code) {
    bool found = false;
    for (int i = 0; i < size; ++i) {
        if (arr[i].getProductCode() == code) {
            cout << "Product found: ";
            arr[i].display();
            found = true;
            break;
        }
    }
    if (!found) {
        cout << "Exception: Product not found" << endl;
    }
}
