#ifndef SENSOR_H
#define SENSOR_H

#include <string>

// Enumeration for calibration state
enum class State { UNCALIBRATED, CALIBRATED, ERROR };

class Sensor {
private:
    int m_id;
    std::string m_type;
    float m_gain;
    float m_offset;
    State m_state;

public:
    // Constructor with member initializer list
    Sensor(int id, std::string type, float gain, float offset, State state);

    // Deleted copy constructor (copying not allowed)
    Sensor(const Sensor&) = delete;

    // Apply calibration parameters
    void applyCalibration(float gain, float offset);

    // Set state using rvalue reference
    void setState(State&& state);

    // Deleted overload (only rvalue ref allowed)
    void setState(const State&) = delete;

    // Accessors
    float getGain() const;
    State getState() const;

    // Display sensor information
    void print() const;
};

#endif
