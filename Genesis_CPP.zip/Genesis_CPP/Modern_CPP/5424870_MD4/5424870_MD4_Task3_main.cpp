#include <iostream>
#include <cstdint>
#include <utility>
#include "5424870_MD4_Task3_SignalBuffer.h"

// Logging functions
void logByRef(const SignalBuffer& b) {
    std::cout << "[By Ref] ";
    b.print();
}

void logByRRef(SignalBuffer&& b) {
    std::cout << "[By RRef] ";
    b.print();
}

void logByPtr(const SignalBuffer* b) {
    std::cout << "[By Ptr] ";
    if (b) b->print();
}

int main() {
    // Step 1: Create SignalBuffer objects in different ways

    // Default constructor
    SignalBuffer a; // default-initialized (m_id = -1 etc.)

    // Member-list constructor
    SignalBuffer buffers[5] = {
        SignalBuffer(501, "Alpha",   -65.0f, 1620000000ULL, Status::VALID),
        SignalBuffer(502, "Beta",    -85.0f, 1620000100ULL, Status::WEAK),
        SignalBuffer(503, "Gamma",   -120.0f,1620000200ULL, Status::LOST),
        SignalBuffer(504, "Delta",   -70.0f, 1620000300ULL, Status::VALID),
        SignalBuffer(505, "Epsilon", -95.0f, 1620000400ULL, Status::WEAK)
    };

    // Uniform initialization (value-initialized temporary)
    SignalBuffer u{ 506, "Zeta", -88.0f, 1620000500ULL, Status::WEAK };

    // Value initialization
    SignalBuffer v{}; // another default

    // In-class default for strength observed in default objects
    std::cout << "Initial objects:\n";
    a.print();
    for (int i = 0; i < 5; ++i) buffers[i].print();
    u.print();
    v.print();
    std::cout << '\n';

    // Step 2: Update strength & status
    buffers[1].updateStrength(-82.5f);            // Beta updated
    buffers[4].setStatus(Status::WEAK);           // allowed via rvalue
    // buffers[4].setStatus(constStatus) is deleted (can't call lvalue version)

    // Step 3: Attempted copy (should be compile-time error) - commented out
    // SignalBuffer copyAttempt = buffers[0];        // ERROR: copy ctor deleted
    // SignalBuffer copyAssign;
    // copyAssign = buffers[1];                      // ERROR: copy assignment deleted

    // Step 4: Use move constructor and move assignment explicitly
    SignalBuffer movedCtor = std::move(buffers[3]); // move-construct from Delta
    std::cout << "\nAfter move-construct (movedCtor from buffers[3]):\n";
    movedCtor.print();
    std::cout << "Original buffers[3] now:\n";
    buffers[3].print(); // moved-from state

    // Move assignment
    SignalBuffer tempAssign(600, "Temp", -60.0f, 1620001000ULL, Status::VALID);
    tempAssign.print();
    tempAssign = std::move(buffers[0]); // move-assign from Alpha
    std::cout << "\nAfter move-assignment (tempAssign = move(buffers[0])):\n";
    tempAssign.print();
    std::cout << "Original buffers[0] now:\n";
    buffers[0].print();

    // Step 5: Demonstrate logging
    std::cout << "\nLogging demonstrations:\n";
    logByRef(buffers[1]);
    logByRRef(std::move(buffers[2])); // moved into logging call
    logByPtr(&buffers[4]);

    // Step 6: Lambdas with different captures
    float threshold = -90.0f;

    // capture by value
    auto capValue = [threshold](const SignalBuffer& b) {
        return b.getStrength() < threshold;
    };

    // capture by reference
    auto capRef = [&threshold](const SignalBuffer& b) {
        return b.getStrength() < threshold;
    };

    // capture-all by value
    auto capAllByValue = [=](const SignalBuffer& b) {
        return b.getStrength() < threshold;
    };

    // capture-all by ref
    auto capAllByRef = [&](const SignalBuffer& b) {
        return b.getStrength() < threshold;
    };

    // init-capture (limit = threshold + 5.0f)
    auto capInit = [limit = threshold + 5.0f](const SignalBuffer& b) {
        return b.getStrength() < limit;
    };

    std::cout << capValue(buffers[0]) << " " << capRef(buffers[0]) << " " << capAllByValue(buffers[0]) << " "
             << capAllByRef(buffers[0]) << " " << capInit(buffers[0]) << "\n";

    // mutable lambda that modifies its captured copy of threshold
    auto mutableLambda = [threshold]() mutable {
        threshold -= 1.0f;
        return threshold;
    };

    // use mutable lambda once to show it changes internal copy
    float mutated = mutableLambda();
    std::cout << "\nMutable lambda returned (internal copy after -1): " << mutated << '\n';
    std::cout << "Original threshold remains: " << threshold << '\n';

    // Step 7: Filter buffers with strength < -90 or status == LOST using lambdas
    SignalBuffer weakSignals[5]; // raw array for filtered results
    int weakCount = 0;
    auto isWeakOrLost = [](const SignalBuffer& b) {
        return (b.getStrength() < -90.0f) || (b.getStatus() == Status::LOST);
    };

    for (int i = 0; i < 5; ++i) {
        // Note: buffers[i] may be moved-from in earlier steps; still safe to query
        if (isWeakOrLost(buffers[i])) {
            // Use move to place into filtered raw array (demonstrate move semantics)
            weakSignals[weakCount++] = std::move(const_cast<SignalBuffer&>(buffers[i]));
        }
    }

    // Step 8: Print filtered results
    std::cout << "\nFiltered weak or lost signals:\n";
    for (int i = 0; i < weakCount; ++i) {
        weakSignals[i].print();
    }

    // Step 9: Document moved-from states after moves
    std::cout << "\nMoved-from states (after move operations):\n";
    std::cout << "buffers[0] (moved-from from earlier move-assignment): ";
    buffers[0].print();
    std::cout << "buffers[2] (moved-into by logByRRef earlier): ";
    buffers[2].print();
    std::cout << "buffers[3] (moved-from by move-construct earlier): ";
    buffers[3].print();

    return 0;
}
