#include <iostream>
#include "5424870_MD4_Task2_Sensor.h"

// Demonstrate lvalue reference
void logSensorByRef(Sensor& s) {
    std::cout << "[By Ref] ";
    s.print();
}

// Demonstrate rvalue reference
void logSensorByRRef(Sensor&& s) {
    std::cout << "[By Rvalue Ref] ";
    s.print();
}

// Demonstrate pointer call
void logSensorByPtr(Sensor* s) {
    std::cout << "[By Pointer] ";
    if (s) s->print();
}

int main() {
    // Step 1: Create sensors using uniform initialization
    Sensor sensors[3] = {
        Sensor{201, "Temperature", 1.05f, 0.2f, State::CALIBRATED},
        Sensor{202, "Pressure", 0.98f, -0.1f, State::UNCALIBRATED},
        Sensor{203, "Humidity", 1.00f, 0.0f, State::ERROR}
    };

    // Step 2: Apply calibration
    sensors[0].applyCalibration(1.10f, 0.25f);
    sensors[1].applyCalibration(1.00f, 0.0f);

    // Step 3: Set state using rvalue reference
    sensors[1].setState(State::CALIBRATED);

    // Step 4: Log sensors
    logSensorByRef(sensors[0]);
    logSensorByRRef(std::move(sensors[1]));
    logSensorByPtr(&sensors[2]);

    // Step 5: Lambda to check if sensor is critical
    auto isCritical = [](const Sensor& s) {
        return s.getGain() > 1.0f || s.getState() == State::ERROR;
    };

    // Step 6: Filter sensors based on lambda
    Sensor criticalSensors[3];
    int criticalCount = 0;

    for (int i = 0; i < 3; ++i) {
        if (isCritical(sensors[i])) {
            criticalSensors[criticalCount++] = std::move(sensors[i]);
        }
    }

    // Step 7: Print critical sensors
    std::cout << "\nCritical Sensors (Gain > 1.0 or State == ERROR):\n";
    for (int i = 0; i < criticalCount; ++i) {
        criticalSensors[i].print();
    }

    return 0;
}
