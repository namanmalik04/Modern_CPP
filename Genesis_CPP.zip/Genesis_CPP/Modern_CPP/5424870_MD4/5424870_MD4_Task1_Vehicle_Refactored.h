#ifndef VEHICLE_REFACTORED_H
#define VEHICLE_REFACTORED_H

#include <string>
#include <iostream>
#include <utility>

// Enum for vehicle status
enum class Status { OK, WARN, FAIL };

class Vehicle {
private:
    int m_id{};
    std::string m_model{};
    double m_temperature{};
    double m_voltage{};
    Status m_status{Status::OK};

public:
    // Constructor using member initializer list and const correctness
    Vehicle(int id, const std::string& model, double temperature, double voltage, Status status);

    // Mutators
    void updateTemperature(double newTemperature);
    void updateVoltage(double newVoltage);
    void setStatus(Status&& newStatus);
    void setStatus(const Status&) = delete;

    // Accessors
    [[nodiscard]] double getTemperature() const noexcept;
    [[nodiscard]] double getVoltage() const noexcept;

    // Utility
    void print() const;
};

#endif
