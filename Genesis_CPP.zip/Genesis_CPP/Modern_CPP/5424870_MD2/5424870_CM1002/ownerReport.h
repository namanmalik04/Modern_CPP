#ifndef OWNERREPORT_H
#define OWNERREPORT_H

#include "Owner.h"
#include <string>

std::string ownerReport(const Owner& owner);

#endif
