#ifndef OWNER_H
#define OWNER_H

#include "VehicleSummary.h"
#include <string>
#include <vector>

class Owner {
private:
    std::string m_name;
    std::vector<VehicleSummary*> m_vehiclePtrs;

public:
    Owner() = delete;                                   // Deleted default constructor
    explicit Owner(const std::string& name);            // Constructor
    Owner(const Owner&) = delete;                       // Deleted copy constructor
    Owner& operator=(const Owner&) = delete;            // Deleted copy assignment
    Owner(Owner&&) noexcept = default;                  // Defaulted move constructor
    Owner& operator=(Owner&&) noexcept = default;       // Defaulted move assignment

    void addVehicle(VehicleSummary* vehiclePtr) noexcept;
    std::vector<std::string> listVehicles() const noexcept;

    const std::string& getName() const noexcept { return m_name; }
    std::size_t getVehicleCount() const noexcept { return m_vehiclePtrs.size(); }
};

#endif
