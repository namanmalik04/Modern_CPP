#ifndef VIN_H
#define VIN_H

#include <string>

// Type alias for VIN
using VIN = std::string;

#endif
