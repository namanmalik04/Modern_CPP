#ifndef VEHICLESUMMARY_H
#define VEHICLESUMMARY_H

#include "VIN.h"
#include <string>

class VehicleSummary {
public:
    VIN vin; // Public member

    explicit VehicleSummary(const VIN& v) noexcept;

    std::string brief() const noexcept;
};

#endif
