#include <iostream>
#include "VehicleSummary.h"
#include "Owner.h"
#include "ownerReport.h"

int main() {
    VehicleSummary v1("VIN-A");
    VehicleSummary v2("VIN-B");

    Owner owner("Rita");

    owner.addVehicle(&v1);
    std::cout << ownerReport(owner) << std::endl; // Expected: Owner:Rita Vehicles:1

    owner.addVehicle(&v2);
    std::cout << ownerReport(owner) << std::endl; // Expected: Owner:Rita Vehicles:2

    auto list = owner.listVehicles();
    for (const auto& s : list) {
        std::cout << s << std::endl;
    }
    // Expected:
    // VIN:VIN-A
    // VIN:VIN-B

    return 0;
}
