#include "ownerReport.h"

std::string ownerReport(const Owner& owner) {
    return "Owner:" + owner.getName() + " Vehicles:" + std::to_string(owner.getVehicleCount());
}
