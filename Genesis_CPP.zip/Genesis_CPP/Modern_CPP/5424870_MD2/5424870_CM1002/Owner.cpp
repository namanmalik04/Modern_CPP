#include "Owner.h"

Owner::Owner(const std::string& name) : m_name(name) {}

void Owner::addVehicle(VehicleSummary* vehiclePtr) noexcept {
    if (vehiclePtr != nullptr) {
        m_vehiclePtrs.push_back(vehiclePtr);
    }
}

std::vector<std::string> Owner::listVehicles() const noexcept {
    std::vector<std::string> result;
    result.reserve(m_vehiclePtrs.size());
    for (auto ptr : m_vehiclePtrs) {
        if (ptr != nullptr) {
            result.push_back(ptr->brief());
        }
    }
    return result;
}
