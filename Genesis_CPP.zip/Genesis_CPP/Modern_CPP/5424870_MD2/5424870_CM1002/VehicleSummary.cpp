#include "VehicleSummary.h"

VehicleSummary::VehicleSummary(const VIN& v) noexcept : vin(v) {}

std::string VehicleSummary::brief() const noexcept {
    return "VIN:" + vin;
}
