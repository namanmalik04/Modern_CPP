#ifndef VEHICLE_H
#define VEHICLE_H

#include <string>

// Scoped enumeration
enum class VehicleType {
    Unknown,
    Car,
    Truck
};

// Abstract base class
class Vehicle {
protected:
    std::string m_vin;
    VehicleType m_type;

public:
    Vehicle() = delete; // Deleted default constructor
    Vehicle(const std::string& vin, VehicleType type) noexcept;
    virtual ~Vehicle() = default;

    virtual std::string description() const = 0; // Pure virtual

    VehicleType getType() const noexcept;
    const std::string& getVin() const noexcept;
};

#endif
