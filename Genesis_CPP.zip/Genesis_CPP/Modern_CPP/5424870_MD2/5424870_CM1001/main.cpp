#include <iostream>
#include <vector>
#include "Car.h"
#include "Truck.h"
#include "printVehicleInfo.h"

int main() {
    Car car("1HGCM82633A004352", 5);
    Truck truck("3H7CM82633A009999", 12.5);

    std::vector<Vehicle*> fleet = { &car, nullptr, &truck };

    for (auto v : fleet) {
        printVehicleInfo(v);
    }

    return 0;
}
