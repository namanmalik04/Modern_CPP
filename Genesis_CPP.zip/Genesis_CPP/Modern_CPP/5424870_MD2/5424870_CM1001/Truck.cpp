#include "Truck.h"

Truck::Truck(const std::string& vin, double payloadTons) noexcept
    : Vehicle(vin, VehicleType::Truck), m_payloadTons(payloadTons) {}

std::string Truck::description() const {
    return "Truck VIN:" + m_vin + " Payload:" + std::to_string(m_payloadTons) + "t";
}
