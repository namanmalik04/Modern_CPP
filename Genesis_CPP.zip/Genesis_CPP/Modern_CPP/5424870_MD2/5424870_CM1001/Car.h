#ifndef CAR_H
#define CAR_H

#include "Vehicle.h"
#include <string>

class Car final : public Vehicle {
private:
    int m_seatCount;
    int m_abc;


public:
    Car() = delete;
    Car(const std::string& vin, int seatCount) noexcept;

    std::string description() const override;

   
};.




#endif
