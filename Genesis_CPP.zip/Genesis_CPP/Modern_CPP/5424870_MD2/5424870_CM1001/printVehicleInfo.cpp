#include "printVehicleInfo.h"

void printVehicleInfo(const Vehicle* vehiclePtr) {
    if (vehiclePtr == nullptr) {
        std::cout << "No vehicle" << std::endl;
    } else {
        std::cout << vehiclePtr->description() << std::endl;
    }
}
