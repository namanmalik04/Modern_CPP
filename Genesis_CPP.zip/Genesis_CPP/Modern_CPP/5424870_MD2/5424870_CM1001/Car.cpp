#include "Car.h"

Car::Car(const std::string& vin, int seatCount) noexcept
    : Vehicle(vin, VehicleType::Car), m_seatCount(seatCount) {}

std::string Car::description() const {
    return "Car VIN:" + m_vin + " Seats:" + std::to_string(m_seatCount);
}
