#include "Vehicle.h"

Vehicle::Vehicle(const std::string& vin, VehicleType type) noexcept
    : m_vin(vin), m_type(type) {}

VehicleType Vehicle::getType() const noexcept {
    return m_type;
}

const std::string& Vehicle::getVin() const noexcept {
    return m_vin;
}
