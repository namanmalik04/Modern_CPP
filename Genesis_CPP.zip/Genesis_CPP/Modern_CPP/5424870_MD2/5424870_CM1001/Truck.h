#ifndef TRUCK_H
#define TRUCK_H

#include "Vehicle.h"
#include <string>

class Truck final : public Vehicle {
private:
    double m_payloadTons;

public:
    Truck() = delete;
    Truck(const std::string& vin, double payloadTons) noexcept;

    std::string description() const override;
};

#endif
