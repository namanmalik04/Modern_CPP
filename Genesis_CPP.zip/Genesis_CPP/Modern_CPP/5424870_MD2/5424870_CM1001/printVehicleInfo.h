#ifndef PRINTVEHICLEINFO_H
#define PRINTVEHICLEINFO_H

#include "Vehicle.h"
#include <iostream>

void printVehicleInfo(const Vehicle* vehiclePtr);

#endif
