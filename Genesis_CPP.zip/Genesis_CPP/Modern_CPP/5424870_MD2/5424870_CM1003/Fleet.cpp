#include "Fleet.h"

void Fleet::addGarage(Garage&& garage) {
    m_garages.push_back(std::move(garage));
}

std::size_t Fleet::totalVehicles() const noexcept {
    std::size_t total = 0;
    for (const auto& g : m_garages) {
        total += g.vehicleCount();
    }
    return total;
}
