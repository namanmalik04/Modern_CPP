#ifndef FLEETVEHICLE_H
#define FLEETVEHICLE_H

#include <memory>
#include <string>
#include "Engine.h"
#include "VehicleState.h"

class FleetVehicle {
private:
    std::string m_id;
    VehicleState m_state;
    std::unique_ptr<Engine> m_engine; // Composition (unique ownership)

public:
    FleetVehicle() = delete; // Deleted default constructor

    // Constructor taking ownership of an existing Engine
    FleetVehicle(const std::string& id, std::unique_ptr<Engine> engine) noexcept;

    // Constructor delegation: id + horsepower
    FleetVehicle(const std::string& id, int horsepower) noexcept;

    void setState(VehicleState state) noexcept;
    int getHP() const noexcept;
    std::string status() const;
};

#endif
