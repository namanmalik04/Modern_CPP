#ifndef GARAGE_H
#define GARAGE_H

#include <string>
#include <vector>
#include <memory>
#include "FleetVehicle.h"

class Garage {
private:
    std::string m_location;
    std::vector<std::unique_ptr<FleetVehicle>> m_vehicles; // Composition (owns FleetVehicles)

public:
    explicit Garage(const std::string& location);

    void addVehicle(std::unique_ptr<FleetVehicle> vehicle) noexcept;
    std::size_t vehicleCount() const noexcept;

    const std::string& getLocation() const noexcept { return m_location; }
};

#endif
