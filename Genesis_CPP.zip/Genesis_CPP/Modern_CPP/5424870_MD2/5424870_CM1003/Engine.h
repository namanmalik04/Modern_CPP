#ifndef ENGINE_H
#define ENGINE_H

class Engine {
private:
    int m_horsepower;

public:
    explicit Engine(int horsepower) noexcept;

    int getHP() const noexcept;
};

#endif
