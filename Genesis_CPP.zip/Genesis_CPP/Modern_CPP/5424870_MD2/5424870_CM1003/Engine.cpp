#include "Engine.h"

Engine::Engine(int horsepower) noexcept : m_horsepower(horsepower) {}

int Engine::getHP() const noexcept {
    return m_horsepower;
}
