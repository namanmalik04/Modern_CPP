#include "Garage.h"

Garage::Garage(const std::string& location)
    : m_location(location) {}

void Garage::addVehicle(std::unique_ptr<FleetVehicle> vehicle) noexcept {
    if (vehicle) {
        m_vehicles.push_back(std::move(vehicle));
    }
}

std::size_t Garage::vehicleCount() const noexcept {
    return m_vehicles.size();
}
