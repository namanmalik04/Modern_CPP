#ifndef FLEET_H
#define FLEET_H

#include <vector>
#include "Garage.h"

class Fleet {
private:
    std::vector<Garage> m_garages;

public:
    Fleet() = default;

    void addGarage(Garage&& garage); // move semantics
    std::size_t totalVehicles() const noexcept;
};

#endif
