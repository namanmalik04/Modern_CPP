#include "FleetVehicle.h"
#include <utility>

FleetVehicle::FleetVehicle(const std::string& id, std::unique_ptr<Engine> engine) noexcept
    : m_id(id), m_state(VehicleState::Parked), m_engine(std::move(engine)) {}

FleetVehicle::FleetVehicle(const std::string& id, int horsepower) noexcept
    : FleetVehicle(id, std::make_unique<Engine>(horsepower)) {}

void FleetVehicle::setState(VehicleState state) noexcept {
    m_state = state;
}

int FleetVehicle::getHP() const noexcept {
    return m_engine ? m_engine->getHP() : 0;
}

std::string FleetVehicle::status() const {
    return "ID:" + m_id +
           " State:" + stateToString(m_state) +
           " HP:" + std::to_string(getHP());
}
