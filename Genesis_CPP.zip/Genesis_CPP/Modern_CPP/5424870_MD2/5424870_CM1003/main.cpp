#include <iostream>
#include "Fleet.h"
#include "FleetVehicle.h"

int main() {
    // Create Garage
    Garage garage("Plant-A");

    // Create a FleetVehicle with id and hp (delegation)
    auto vehicle = std::make_unique<FleetVehicle>("F123", 150);
    vehicle->setState(VehicleState::Parked);

    // Add vehicle into garage (composition)
    garage.addVehicle(std::move(vehicle));

    // Create Fleet and move garage into it
    Fleet fleet;
    fleet.addGarage(std::move(garage));

    std::cout << "Total vehicles in fleet: " << fleet.totalVehicles() << std::endl;

    // Independent test of FleetVehicle behavior
    FleetVehicle fv2("F200", 200);
    std::cout << fv2.status() << std::endl; // Default state: Parked

    fv2.setState(VehicleState::InTransit);
    std::cout << fv2.status() << std::endl; // Updated state: InTransit

    return 0;
}
