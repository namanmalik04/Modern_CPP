#ifndef VEHICLESTATE_H
#define VEHICLESTATE_H

#include <string>

// Scoped enumeration
enum class VehicleState {
    Parked,
    InTransit,
    Maintenance
};

// Helper function to convert state to string
inline std::string stateToString(VehicleState state) {
    switch (state) {
        case VehicleState::Parked: return "Parked";
        case VehicleState::InTransit: return "InTransit";
        case VehicleState::Maintenance: return "Maintenance";
        default: return "Unknown";
    }
}

#endif
