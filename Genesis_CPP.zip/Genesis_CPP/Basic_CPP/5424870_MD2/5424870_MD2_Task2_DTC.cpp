#include "5424870_MD2_Task2_DTC.h"
// Implementation is already inline in header for simplicity
